package br4cp;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

/*   (C) Copyright 2013, Schmidt Nicolas
 * 
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

public class Variance {

	ArrayList <Var> variables;
	int count;
	double[][] variance;
	int meth;
	
	public Variance(ArrayList<Var> v, VDD graph, int methode, String name){
		meth=methode;
		variables=v;
		variance=new double[variables.size()][variables.size()];
		
		if(!load(name)){
		
		//tout a 0
		if(meth==0){
			for(int i=0; i<v.size(); i++){
				for(int j=i+1; j<v.size(); j++){
					variance[i][j]=0;
				}
			}
		}
		
		//methode initiale, diff des ecarts de proba.
		//marche sur domaine binaire, val > 1 sur valeurs non binaires
		if(meth==1){
		
		count=graph.countingpondere();	
		
		double[] probabilite;
		double probaTemp;
		Var var1, var2;
		int dom1, dom2, count2;
		double facteur;
		double distance;
		for(int i=0; i<v.size(); i++){
			var1=v.get(i);
			System.out.println();
			System.out.println(var1.name);
			for(int j=i+1; j<v.size(); j++){
				var2=v.get(j);
					
				distance=0;
				dom1=var1.domain;
				dom2=var2.domain;
				probabilite=new double[dom2];
				
				//calcul des probab initiales
				for(int k=0; k<dom2; k++){
					probabilite[k]=graph.countingpondereOnVal(var2, k);
					probabilite[k]=probabilite[k]/count;
				}				
				
				//calcul des proba au cas par cas
				for(int l=0; l<dom1; l++){
					graph.conditioner(var1, l);
					count2=graph.countingpondere();
					facteur=count2;
					facteur=facteur/count;
					for(int k=0; k<dom2; k++){
						graph.conditioner(var1, l);
						probaTemp=graph.countingpondereOnVal(var2, k);
						probaTemp=probaTemp/count2;
						graph.conditioner(var1, l);
						//System.out.println(graph.countingpondereOnVal(var2, k)+ " "+count2);
						distance+=Math.abs((probaTemp-probabilite[k])*facteur);
					}
					graph.deconditioner(var1);
				}
				variance[i][j]=distance;
				System.out.print(var2.name+"="+(double)(Math.round(distance*100))/100+" ");

			}
		}
		}
		
		//calcule de l'écart max
		if(meth==2){
			count=graph.countingpondere();	
			
			double[] probabilite;
			double probaTemp;
			Var var1, var2;
			int dom1, dom2, count2;
			double facteur;
			double distance;
			double maxproba;
			double maxprobapossible;
			
			for(int i=0; i<v.size(); i++){
				var1=v.get(i);
				System.out.println();
				System.out.println(var1.name);
				for(int j=i+1; j<v.size(); j++){
//				for(int j=0; j<v.size(); j++){
					var2=v.get(j);
						
					distance=0;
					dom1=var1.domain;
					dom2=var2.domain;
					probabilite=new double[dom2];
					
					//calcul des probab initiales
					for(int k=0; k<dom2; k++){
						probabilite[k]=graph.countingpondereOnVal(var2, k);
						probabilite[k]=probabilite[k]/count;
					}				
					
					//calcul des proba au cas par cas
					for(int l=0; l<dom1; l++){
						maxproba=0;
						maxprobapossible=0;
						
						graph.conditioner(var1, l);
						count2=graph.countingpondere();
						facteur=count2;
						facteur=facteur/count;
						for(int k=0; k<dom2; k++){
							graph.conditioner(var1, l);
							probaTemp=graph.countingpondereOnVal(var2, k);
							probaTemp=probaTemp/count2;
							graph.conditioner(var1, l);
							//System.out.println(graph.countingpondereOnVal(var2, k)+ " "+count2);
							
							if(Math.abs(probaTemp-probabilite[k])>maxproba)
								maxproba=Math.abs(probaTemp-probabilite[k]);
							if(1-probabilite[k] > maxprobapossible)
								maxprobapossible=1-probabilite[k];
							//distance+=Math.abs((probaTemp-probabilite[k])*facteur);
						}
						maxproba=maxproba/maxprobapossible;
						distance+=maxproba*facteur;
						graph.deconditioner(var1);
					}
					
					variance[i][j]=distance;
					System.out.print(var2.name+"="+(double)(Math.round(distance*100))/100+" ");

				}
			}
		}
		
		if(meth==3){
			
		count=graph.countingpondere();	
		
		double[] probabilite1;
		double[] probabilite2;
		double probaTemp;
		Var var1, var2;
		int dom1, dom2, count2;
		double facteur;
		double distance;
		for(int i=0; i<v.size(); i++){
			var1=v.get(i);
			System.out.println();
			System.out.println(var1.name);
			for(int j=i+1; j<v.size(); j++){
				
				//---debut du calcul-----
				var2=v.get(j);
					
				distance=0;
				dom1=var1.domain;
				dom2=var2.domain;
				probabilite1=new double[dom1];
				probabilite2=new double[dom2];
				
				//calcul des probab initiales
//				for(int k=0; k<dom1; k++){
//					probabilite1[k]=graph.countingpondereOnVal(var1, k);
//				}
				//calcul des probab initiales
				for(int k=0; k<dom2; k++){
					probabilite2[k]=graph.countingpondereOnVal(var2, k);
				}				
				//calcul des proba au cas par cas
				for(int l=0; l<dom1; l++){
					probabilite1[l]=graph.countingpondereOnVal(var1, l);
					for(int k=0; k<dom2; k++){
						graph.conditioner(var1, l);

						//graph.conditioner(var1, l);
						probaTemp=graph.countingpondereOnVal(var2, k);
						facteur=probabilite1[l]*probabilite2[k];
						if(facteur>5){
							facteur=facteur/count;
							distance+=Math.pow(probaTemp-facteur, 2)/facteur;
						}
						}
					graph.deconditioner(var1);
				}
				variance[i][j]=distance;
				System.out.print(var2.name+"="+(double)(Math.round(distance*100))/100+" ");
				//System.out.print(var2.name+"="+distance+" ");


			}
		}
		}
		save(name);
		}
		
		
    } 

	
	public void string(){
		for(int i=0; i<variables.size(); i++){
			for(int j=0; j<variables.size(); j++){
				System.out.print(variance[i][j]+" ");
			}
			System.out.println();
		}
	}
	
	public double get(Var v1, Var v2){
		int index1, index2;
		double val1, val2;
		index1=variables.indexOf(v1);
		index2=variables.indexOf(v2);
		val1=variance[index1][index2];
		val2=variance[index2][index1];
		if (val1>val2)
			return val1;
		return val2;

	}
	
	//name : small medium big?
	public void save(String name){
		String file="var_"+name+"_m"+meth+".txt";
		
		String ligne;
		
	   	FileWriter fW;

		try{
			fW = new FileWriter(file);
		
			for(int i=0; i<variance.length; i++){
				ligne="";
				for(int j=0; j<variance[i].length; j++){
					ligne+=""+variance[i][j]+" ";
				}
				fW.write(ligne+"\n");
			}
			fW.close();

	}catch (Exception e){
		System.out.println(e.toString());
	}
	}
	
	public boolean load(String name){
		String file="var_"+name+"_m"+meth+".txt";
		
		String ligne;
		
		FileReader fR;
		InputStream ips;
		InputStreamReader ipsr=null;
		BufferedReader br=null;
		
		File f=new File(file);
		
		String numbers[];
		int i=0;
		
		if(f.canRead()){

			try{
			fR = new FileReader(file);
		
			ips=new FileInputStream(file); 
			ipsr=new InputStreamReader(ips);
			br=new BufferedReader(ipsr);
			
			while((ligne=br.readLine())!=null){
			
				numbers=ligne.split(" ");
				for(int j=0; j<variance[i].length; j++){
					variance[i][j]=Double.parseDouble(numbers[j]);
				}
				i++;
			}

			}catch (Exception e){
				System.out.println(e.toString());
			}
		}else
			return false;
		
		return true;
	}
		

}
