package br4cp;

	/*   (C) Copyright 2014, Schmidt Nicolas
	 * 
	 *   This program is free software: you can redistribute it and/or modify
	 *   it under the terms of the GNU General Public License as published by
	 *   the Free Software Foundation, either version 3 of the License, or
	 *   (at your option) any later version.
	 *
	 *   This program is distributed in the hope that it will be useful,
	 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
	 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	 *   GNU General Public License for more details.
	 *
	 *   You should have received a copy of the GNU General Public License
	 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
	 */


	import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.Map;


import java.io.*;


	
	public class CompilateurSLDD implements Configurator {

		//private VDD y;//saveVDD;
		private VDD x;//testVDD;
		private String inX;
		//private String inY;
		private Protocol p;
		
		private ArrayList<String> historiqueOperations;

		public CompilateurSLDD(Protocol pro){
			if(pro!=null)
				p=pro;
			else
				p=Protocol.BT;
			
			historiqueOperations=new ArrayList<String>();
			inX="";
			
		}
		
		public VDD compilation(ArrayList<String> FichiersACompiler, boolean arg_plus, int arg_heuristique, int arg_heuristique_cons, String arg_formefinale, String arg_FichierSortie, boolean flag_fichierSortie, boolean flag_beg, int arg_affich_text){
			
			
			Ordonnancement ord;
			
			long start= System.currentTimeMillis();
			long end;
			
			ord = new Ordonnancement();


			
			LecteurXML xml=new LecteurXML(ord);
			if(arg_plus==true){
				xml.lecture(FichiersACompiler.get(0));
			}else{	
				xml.lectureBIF(FichiersACompiler.get(0));
			}

			for(int i=0; i<FichiersACompiler.size(); i++)
				xml.lectureSuite(FichiersACompiler.get(i));
			
			ord.addVarialbes(xml.getVariables());
			
			if(xml.getNbVariables()!=ord.size())
				System.out.println("bug nb variables");
			
			
			
			//reordonnancement
			ord.reordoner(xml.getInvolvedVariablesEntree(), arg_heuristique, false);			//<---
//			ord.reordoner(xml.getScopeID(), 7);							//<---
			xml.actualiseVariables();
			//ord.afficherOrdre();
			//ord.getInfo(xml.getInvolvedVariablesEntree());
			xml.compactConstraint();
			
			
			UniqueHashTable uht=new UniqueHashTable(ord.size());
			VDD x =new VDD(ord.getVariables(), uht, arg_plus);

			//x.addToSlddMult();
			//System.out.println("sldd" + x[bclD].uht.size());
				
			x.flagMult=(!arg_plus);											//<---
			x.flagPlus=arg_plus;											//<---
			//x.flagOperateurPrincipalMultiplication=(!arg_plus);				//<---
			//contraintes[tuples][arity];	
			//poid[tuples]
				
		
			int contraintes[][];
			String contraintesS[][];
			Structure Poids[];
			Structure defaultCost;
			boolean softConstraint;
			boolean conflictsConstraint;
			
			xml.reorganiseContraintes(arg_heuristique_cons);
			
			if(arg_affich_text==3){
				ord.afficherOrdre();
				xml.afficheOrdreContraintes();
			}
			
		
			for(int i1=0; i1<xml.nbConstraints; i1++){
//			for(int i=xml.nbConstraints-1; i>=0; i--){
				int i=xml.equiv(i1);
			

			//for(int i=0; i<1; i++){
				contraintesS=xml.getConstraintS(i);
				contraintes=xml.getConstraint(i);
				if(contraintesS!=null){
					Poids=xml.getPoid(i);
					if(contraintesS.length!=0){
						defaultCost=xml.getDefaultCost(i);
						softConstraint=xml.getSoftConstraint(i);
						conflictsConstraint=xml.getConflictsConstraint(i);
					

						contraintes=new int[contraintesS.length][contraintesS[0].length];
									
					//traduction en valeur de 0 a n (au lieu de strings)
						for(int j=0; j<contraintes.length; j++){
							for(int k=1; k<contraintes[j].length; k++){
								contraintes[j][k]=ord.getVariables().get(k-1).conv(contraintesS[j][k]);
							}
						}
						/*for(int l=1; l<contraintes[0].length; l++){
							if(contraintes[0][l]!=-1){
								System.out.print(x[bclD].variables.get(l-1).name + " ");
							}
						}
						System.out.println();*/
			//			x.ajoutDefaultCost(contraintes[0], defaultCost, softConstraint);
					
						//for(int j=0; j<contraintes.length; j++){
							//System.out.println("contraintes : " + contraintes[j][0] + contraintes[j][1] + contraintes[j][2]+ contraintes[j][3]+ contraintes[j][4] + "   poid : " + poid[j]);
						x.valeurChemin(contraintes, Poids, defaultCost, softConstraint, conflictsConstraint);
			
							/*if(j%800==0 && j!=0){			//on cotracte au milieu de contraintes trop longues
								x.addToSldd();	
								x.contract();	
								System.out.println(j);
							}*/
						//}
						
			//			ut.cutBottom();
			//			x.comb();	
			//			x.contract();
			//			ut.cutBottom();
						
			//			if(i>156 && i<162)
							//x.toDot("xsldd"+(i+1), true);
						
						//uht.detect();
						if(arg_affich_text>=2){
							end=System.currentTimeMillis();
							System.out.println(i1+":sldd"+(i+1)+"/"+xml.nbConstraints+"  nbnoeuds:" + x.uht.size() + " (" + x.uht.sizeArcs() + ")   " + (end-start)/1000+","+(end-start)%1000 + "s");
						}		
					}
				}
//				x[bclD].toDot("xsldd"+bclD, true);

			}

			//affiche les resultats, es supprim les noeuds beg si besoin
			x.affichageResultats(arg_affich_text, start, flag_beg);

			
			
//			System.out.println(x[0].counting());
			//x[0].uht.rechercheNoeudInutile();

			//System.out.println("++++++++++++++++");
			//uht.detail();
			//System.out.println("++++++++++++++++");
			
//			uht.reintroductionNoeuds(xml.var, true, false);
//			uht.compterNeudsSansPere();
//			x[0].uht.normaliser();
//			System.out.println(x[0].counting());
			
			//x[0].toXML("test");
//			if(p==Protocol.FCP || p==Protocol.GC_p || p==Protocol.GC_Expl || p==Protocol.GC_Res ){
//				x.toDot(arg_FichierACompiler+"_P_compiled",false);
//			}else{
//				x.toDot(arg_FichierACompiler+"_compiled",false);
//			}

			x.transformation(arg_formefinale, arg_affich_text);


			if(flag_fichierSortie){
				x.toDot(arg_FichierSortie, false);
				//x.toXML(arg_FichierSortie);
				//System.out.println(arg_formefinale+" : " + x.uht.size() + " nodes and " + x.uht.sizeArcs() + " edges");
			}
			
			
//			System.out.println(x.counting());
//			System.out.println(x.countingpondere());
//			x.conditioner(1, 0);
//			System.out.println(x.countingpondere());
//			
//			x.mostchoosen(3);
//			x.mostchoosen(7);
//			x.mostchoosen(9);
//			x.mostchoosen(11);
			
			return x;
		}
		


		public VDD chargement(String arg_FichierACharger, String arg_formefinale, String arg_FichierSortie, boolean flag_fichierSortie, boolean flag_beg, int text){
			//String arg_FichierACharger = "";
/*			String arg_formefinale="";
			String arg_FichierSortie="";
			boolean flag_fichierSortie=false;
			
			if(args.length<2){
				arg_err=true;
				System.out.println("pas assez d'arguments");
			}
			
			//file
			arg_FichierACharger=args[0];
		
			/*if(args.length>1){
				arg_formefinale=args[1];
				if(!(arg_formefinale.contains("AADD") || arg_formefinale.contains("SLDDp") || arg_formefinale.contains("SLDDt") || arg_formefinale.contains("ADD")) ){
					arg_err=true;
					System.out.println("erreur : forme final ("+ args[1] +") non accepté. possibilités : AADD, SLDDp, SLDDt, ADD");
				}
			}else{
				arg_formefinale="prout";
			}
			
			if(args.length>2){
				flag_fichierSortie=true;
				arg_FichierSortie=args[2];
			}
			
			
			if(arg_err){
				System.out.println("programme interompu");
				System.exit(0);
			}*/
			
			
//			UniqueHashTable uht;
			///////////////lecture fichier////////////////
			LecteurDot l;
			l=new LecteurDot(arg_FichierACharger);
			VDD x=l.getVDD();
//			uht=l.getuht();
			
			System.out.println("chargement " + x.uht.size() + " (" + x.uht.sizeArcs() + ")");

			x.transformation(arg_formefinale, text);

			/*if(!x.flagMult){			//ADD ou SLDDp
				if(!x.flagPlus){		//ADD
					System.out.println("ADD " + x.uht.size() + " (" + x.uht.sizeArcs() + ")");
				}else{				//SLDDp
					System.out.println("SLDD+ " + x.uht.size() + " (" + x.uht.sizeArcs() + ")");
				}
			}else{
				if(!x.flagPlus){		//SLDDt
					System.out.println("SLDD* " + x.uht.size() + " (" + x.uht.sizeArcs() + ")");
				}else{				//AADD
					System.out.println("AADD " + x.uht.size() + " (" + x.uht.sizeArcs() + ")");
				}
			}
			
			if(x.flagMult && x.flagPlus){		//AADD
				if((arg_formefinale.contains("SLDD") || arg_formefinale.contains("ADD")) && !arg_formefinale.contains("AADD"))
					System.out.println("impossible de traduire la forme AADD vers un autre language");
				System.exit(0);
			}
			
			
	/*		if(x.flagPlus && !x.flagMult){		//sldd+ vers autre
				if(arg_formefinale.contains("AADD")){
					x.slddToAadd();
					x.contract();
					System.out.println("aadd " + x.ut.size() + " (" + x.ut.sizeArcs() + ")");
				}else{
					if(arg_formefinale.contains("ADD")){
						x.slddToAdd();
						x.contract();
						System.out.println("add " + x.ut.size() + " (" + x.ut.sizeArcs() + ")");
					}else{
						if(arg_formefinale.contains("SLDDt")){
							x.slddToAdd();
							x.contract();
							System.out.println("add " + x.ut.size() + " (" + x.ut.sizeArcs() + ")");
							x.addToSlddMult();
							x.contract();
							System.out.println("slddt " + x.ut.size() + " (" + x.ut.sizeArcs() + ")");
						}
					}
				}
			}
			if(!x.flagPlus && x.flagMult){				//slddt vers autre
				if(arg_formefinale.contains("AADD")){
					x.slddMultToAadd();
					x.contract();
					System.out.println("aadd " + x.ut.size() + " (" + x.ut.sizeArcs() + ")");
				}else{
					if(arg_formefinale.contains("ADD")){
						x.slddMultToAdd();
						x.contract();
						System.out.println("add " + x.ut.size() + " (" + x.ut.sizeArcs() + ")");
					}else{
						if(arg_formefinale.contains("SLDDp")){
							x.slddMultToAdd();
							x.contract();
							System.out.println("add " + x.ut.size() + " (" + x.ut.sizeArcs() + ")");
							x.addToSldd();
							x.contract();
							System.out.println("slddp " + x.ut.size() + " (" + x.ut.sizeArcs() + ")");
						}
					}
				}
			}
			if(!x.flagPlus && !x.flagMult){				//add vers autre
				if(arg_formefinale.contains("SLDDp")){
					x.addToSldd();
					x.contract();
					System.out.println("slddp " + x.ut.size() + " (" + x.ut.sizeArcs() + ")");
				}else{
					if(arg_formefinale.contains("SLDDt")){
						x.addToSlddMult();
						x.contract();
						System.out.println("slddt " + x.ut.size() + " (" + x.ut.sizeArcs() + ")");
					}else{
						if(arg_formefinale.contains("AADD")){
							//doit on passer par la forme SLDD+ ou SLDD* ???
							if(x.testplus_testtime()){		//on passe par SLDD+
								x.addToSldd();
								x.contract();
								System.out.println("slddp " + x.ut.size() + " (" + x.ut.sizeArcs() + ")");
								x.slddToAadd();
								x.contract();
								System.out.println("aadd " + x.ut.size() + " (" + x.ut.sizeArcs() + ")");
							}else{							//on passe par SLDD*
								x.addToSlddMult();
								x.contract();
								System.out.println("slddt " + x.ut.size() + " (" + x.ut.sizeArcs() + ")");
								x.slddMultToAadd();
								x.contract();
								System.out.println("aadd " + x.ut.size() + " (" + x.ut.sizeArcs() + ")");
							}
						}
					}
				}
			}*/
			
			/*if(flag_fichierSortie){
				x.toDot(arg_FichierSortie, false);
			}*/
			return x;
		}
		
	    //////////////
	    // Protocol //
	    //////////////
	    




	    	/**
	    	 * Read a configuration file. Both the xml format and the textual format
	    	 * will be provided. It is up to the solver to choose which format to use.
	    	 * Note that the prices are expected to be found in a file with a "_prices"
	    	 * postfix.
	    	 * 
	    	 * 
	    	 * @param problemName
	    	 *            the path to the problem, without the extension (.xml or .txt)
	    	 */
	    public void readProblem(String problemName){
	    	// TODO Auto-generated method stub	
	    			
	    	ArrayList<String> pbnames=new ArrayList<String>();
			pbnames.add(problemName+".xml");

	    	String problemNamePriceornot;
			if(p==Protocol.FCP || p==Protocol.GC_p || p==Protocol.GC_Expl || p==Protocol.GC_Res ){
				problemNamePriceornot=problemName+"_P";
				pbnames.add(problemName+"Prices.xml");
			}else{
				problemNamePriceornot=problemName;
			}
	    			
	    			if(x==null || inX.compareTo(problemNamePriceornot)!=0){
	    				File f=new File(problemNamePriceornot+"_compiled.dot");
	    				if(f.canRead()){
	    					System.out.println("lecture du fichier compilé \""+problemNamePriceornot+"_compiled.xml\"");
	    					LecteurDot lcd=new LecteurDot(problemNamePriceornot+"_compiled");
	    					x=lcd.x;
	    					inX=problemNamePriceornot;
	    				}else{
	    					System.out.println("compilation (attention, cette operation peut prendre plusieurs minutes)");
	    					x=compilation(pbnames, true, 3, 0, "", (problemNamePriceornot+"_compiled"), true, true, 0);

	    					inX=problemNamePriceornot;
	    				}
	    			}else{
	    			//	System.out.println("Réinitialisation du problème");
	    				x.deconditionerAll();
	    			}
	    	}
	    
	    	/**
	    	 * Such method should be used by the configurator to perform the tasks on the configuration problem
	    	 * before the first user choice. 
	    	 * This method can be used for instance to maintain GIC on the initial configuration problem.
	    	 * This method MUST BE called after {@link #readProblem(String)} and before any other method of the interface.
	    	 */
			public void initialize(){
				x.minMaxConsistance();
			}


	    	/**
	    	 * Assign a specific value to a variable.
	    	 * 
	    	 * @param var
	    	 * @param val
	    	 * @return true iff the assignment can be done
	    	 * @pre getCurrentDomainOf(var).contains(val)
	    	 */
			//public void assignAndPropagate(String var, String val){
	    	public void assignAndPropagateNoMaj(String var, String val){
	    		if(!isPresentInCurrentDomain(var, val))
	    			System.out.println(val+" non presente dans "+var+". aucune operation effectue");
	    		else{
		    		Var v=x.getVar(var);
					x.conditioner(v, v.conv(val));
					x.minMaxConsistance();
	    		}
				
	    		historiqueOperations.add(var);
	    		historiqueOperations.add(val);
	    	}
	    	
	    	public void assignAndPropagate(String var, String val){
	    		if(!isPresentInCurrentDomain(var, val))
	    			System.out.println(val+" non presente dans "+var+". aucune operation effectue");
	    		else{
		    		Var v=x.getVar(var);
					x.conditioner(v, v.conv(val));
					x.minMaxConsistanceMaj(v.pos, true);
	    		}
				
	    		historiqueOperations.add(var);
	    		historiqueOperations.add(val);
	    	}
	    	
	    	public void assignAndPropagateOpt(String var, String val){
	    		if(!isPresentInCurrentDomain(var, val))
	    			System.out.println(val+" non presente dans "+var+". aucune operation effectue");
	    		else{
		    		Var v=x.getVar(var);
					x.conditioner(v, v.conv(val));
					x.minMaxConsistanceMajopt(v.pos, true);
					
					//x.GICup();
	    		}
		    		historiqueOperations.add(var);
		    		historiqueOperations.add(val);
	    	}
	    	

	    	/**
	    	 * Unassign a specific variable
	    	 * 
	    	 * @param var
	    	 */
	    	public void unassignAndRestoreSansMaj(String var){
	    		Var v=x.getVar(var);
	    		x.deconditioner(v);
	    		x.minMaxConsistance();
	    		
	    		int index=historiqueOperations.indexOf(var);
	    		historiqueOperations.remove(index);
	    		historiqueOperations.remove(index);
	    	}
	    	
	    	public void unassignAndRestore(String var){
	    		Var v=x.getVar(var);
	    		x.deconditioner(v);
	    		x.minMaxConsistanceMaj(v.pos, false);
	    		
	    		int index=historiqueOperations.indexOf(var);
	    		historiqueOperations.remove(index);
	    		historiqueOperations.remove(index);
	    	}
	    	
	    	public void unassignAndRestoreOpt(String var){
	    		Var v=x.getVar(var);
	    		x.deconditioner(v);
	    		x.minMaxConsistanceMajopt(v.pos, false);
	    		
	    		int index=historiqueOperations.indexOf(var);
	    		historiqueOperations.remove(index);
	    		historiqueOperations.remove(index);
	    	}

	    	/**
	    	 * Get the minimal price of the configurations compatible with the current
	    	 * choices.
	    	 * 
	    	 * @return the cost of the configuration
	    	 */
	    	public int minCost(){
	    		return (int)x.min.getvaldouble();
	    	}

	    	/**
	    	 * Provide a full configuration of minimal cost.
	    	 * 
	    	 * @return a full assignment var->value of minimal cost (given by {@link #minCost()}
	    	 */
	    	public Map<String, String> minCostConfiguration(){
	    		return x.minCostConfiguration();
	    	}

	    	/**
	    	 * Get the maximal price of the configurations compatible with the current
	    	 * choices.
	    	 * 
	    	 * @return the cost of the configuration
	    	 */
	    	public int maxCost(){
	    		return (int)x.max.getvaldouble();
	    	}    	
	    	/**
	    	 * Provide a full configuration of maximal cost.
	    	 * 
	    	 * @return a full assignment var->value of maximal cost (given by {@link #maxCost()}
	    	 */
	    	public Map<String, String> maxCostConfiguration(){
	    		return x.maxCostConfiguration();
	    	}

	    	/**
	    	 * @inv getSizeOfCurrentDomain(var) == getCurrentDomainOf(var).size()
	    	 */
	    	public int getSizeOfCurrentDomainOf(String var){
	    		return x.getVar(var).consistenceSize();    		
	    	}

	    	/**
	    	 * 
	    	 * @param var
	    	 * @param val
	    	 * @return
	    	 * @inv isCurrentInCurrentDomain(var,val)==
	    	 *      getCurrentDomainOf(var).contains(val)
	    	 */
	    	public boolean isPresentInCurrentDomain(String var, String val){
	    		Var v=x.getVar(var);
	    		return v.consVal[v.conv(val)];
	    	}

	    	public Set<String> getCurrentDomainOf(String var){
	    		Set<String> s=new HashSet<String>();
	    		Var v=x.getVar(var);
	    		for(int i=0; i<v.domain; i++){
	    			if(v.consVal[i])
	    				s.add(v.valeurs.get(i));
	    			
	    		}
	    		return s;
	    	}

	    	/**
	    	 * Retrieve for each valid value of the variable the minimal cost of the
	    	 * configuration.
	    	 * 
	    	 * @param var
	    	 *            a variable id
	    	 * @return a map value->mincost
	    	 */
	    	public Map<String, Integer> minCosts(String var){
	    		Var v=x.getVar(var);
	    		Map<String, Integer> m;
	    		m=x.minCosts(v.pos);
	    		x.minMaxConsistanceMaj(v.pos, true);
	    		return m;
	    	} 

	    	/**
	    	 * Retrieve for each valid value of the variable the maximal cost of the
	    	 * configuration.
	    	 * 
	    	 * @param var
	    	 *            a variable id
	    	 * @return a map value->maxcost
	    	 */
	    	public Map<String, Integer> maxCosts(String var){
	    		Var v=x.getVar(var);
	    		Map<String, Integer> m;
	    		m=x.maxCosts(v.pos);
	    		x.minMaxConsistanceMaj(v.pos, true);
	    		return m;
	    	} 

	    	/**
	    	 * Get all unassigned variables.
	    	 * 
	    	 * @return a set of non assigned variables.
	    	 */
	    	public Set<String> getFreeVariables(){
	    		Set<String> s=new HashSet<String>();
	    		for(int i=0; i<x.variables.size(); i++){
	    			if(x.variables.get(i).consistenceSize()>1)
	    				s.add(x.variables.get(i).name);
	    		}
	    		return s;
	    	}

	    	/**
	    	 * Check that there is no more choice for the user.
	    	 * 
	    	 * @return true iff there is exactly one value left per variable.
	    	 */
	    	public boolean isConfigurationComplete(){
	    		return getFreeVariables().size()==0;	
	    	}

	    	/**
	    	 * Check there there is at least one value in each domain. Note that
	    	 * depending of the level of consistency used, the configuration may of may
	    	 * not be finally consistent.
	    	 * 
	    	 * @return true iff there is at least one value left per variable.
	    	 */
	    	public boolean isPossiblyConsistent(){
	    		System.out.println("m&m : "+x.max.getvaldouble()+" "+x.min.getvaldouble());
	    		return x.min.getvaldouble()!=-1;
	    	}

	    	//lapin compris
	    	public Set<String> getAlternativeDomainOf(String var){
	    		return null;
	    	}
		
	    	public void infos(String var){
	    		Var v=x.getVar(var);
	    		x.countingpondereOnFullDomain(v);
	    	}
	    	
	    	//recomandation sur la variable var
	    	public void reco(String var){
	    		Var v=x.getVar(var);
	    		x.reco(v, historiqueOperations);
	    	}
	    	
	    	public void variance(int methode, String name){
	    		x.variance(methode, name);
	    	}
	}


	/*		int iterations=30;
			int []v=new int[iterations];
			int []d=new int[iterations];
			long start2= System.nanoTime();
			long end2;
			long sum=0;
			
			for(int i=0; i<iterations; i++){
				v[i]=(int)Math.floor(Math.random()*x[0].variables.size());
				d[i]=(int)Math.floor(Math.random()*x[0].variables.get(v[i]).domain);
			}	*/	
			
			


			
			/*
			y=x[0].clone();
			x[0]=y.clone();
			end2= System.nanoTime();
			System.out.println("clone :  " + (double)(end2-start2) /1000000000+ "s");

			for(int i=0; i<iterations; i++){
				//v=(int)Math.floor(Math.random()*x[0].variables.size());
				//d=(int)Math.floor(Math.random()*x[0].variables.get(v).domain);
				x[0].conditioner(v[i]+1,d[i]);
				x[0].minMaxConsistance();
				x[0].deconditioner(v[i]+1);
			}
			
			for(int i=0; i<iterations; i++){
				start2= System.nanoTime();
				//v=(int)Math.floor(Math.random()*x[0].variables.size());
				//d=(int)Math.floor(Math.random()*x[0].variables.get(v).domain);
				x[0].conditioner(v[i]+1,d[i]);
				x[0].minMaxConsistance();
				end2=System.nanoTime();
				sum+=end2-start2;
				x[0].deconditioner(v[i]+1);
			}
			System.out.println("opt :  " + (double)(sum) /1000000000+ "s");
			
			sum=0;
			

			for(int i=0; i<iterations; i++){
				start2= System.nanoTime();
				//v=(int)Math.floor(Math.random()*x[0].variables.size());
				//d=(int)Math.floor(Math.random()*x[0].variables.get(v).domain);
				y.conditionerTrue(v[i]+1,d[i]);			
				end2=System.nanoTime();
				sum+=end2-start2;
				y=null;
				y=x[0].clone();
			}
			System.out.println("cd :  " + (double)(sum) /1000000000+ "s");*/


			
			
			//end2=System.nanoTime();
			//System.out.println("co :  " + (double)(end2-start2) /1000000000+ "s");
			//System.out.println("co :  " + (double)(sum) /1000000000+ "s");


/*	String nameFile="CDdaniel";
	LecteurCdXml lxd;
	lxd=new LecteurCdXml();
	lxd.ecritureInit(nameFile);
	for(int j=0; j<1000; j++){
	x[0].deconditionerAll();
	//lxd.lectureXml("smallGloutonSenarDaniel.xml", j, x[0].variables.size());
	lxd.lectureTxt("scenarios-big", j, x[0].variables.size());
	
	System.out.println(j);
	x[0].minMaxConsistance();
	for(int i=0; i<x[0].variables.size(); i++){
		Var v=x[0].getVar(lxd.var[i]);
		if(v.consistenceSize()>1){
			x[0].conditioner(v, v.conv(lxd.dom[i]));
			x[0].minMaxConsistance();
			lxd.ecriture(nameFile, v, lxd.dom[i], (int)x[0].min.getvaldouble(), (int)x[0].max.getvaldouble());
		}
	}
	lxd.ecriture2(nameFile);
	}*/