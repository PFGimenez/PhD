/*   (C) Copyright 2013, Schmidt Nicolas
 * 
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.util.ArrayList;
import java.util.Timer;
import java.math.*;

import java.lang.management.*;

import br4cp.*;

public class Main {



	
	public static void main(String[] args) {
		
		CompilateurSLDD cs;
		cs=new CompilateurSLDD(Protocol.FCP);
		long sum=0, temps, start, start1, start2, start3, start4, start5, temps1, temps2, temps3, temps4, sum2=0;
		int nbactions=0;
		LecteurCdXml lecteur=new LecteurCdXml();
		cs.readProblem("big");

		//cs.readProblem("hbigPrices");
		//for(int i=0; i<1000; i++){
		int i=0;
			//lecteur.lectureXml("scenarios-big-minimal.xml", i);
			start1=System.currentTimeMillis();
			cs.readProblem("big");
			temps1=System.currentTimeMillis()-start1;
			start2=System.currentTimeMillis();
			cs.initialize();
			temps2=System.currentTimeMillis()-start2;
			start3=System.currentTimeMillis();
/*			System.out.println(cs.maxCost() +" " + cs.minCost());
			System.out.println(System.currentTimeMillis()-start2+"ms init");
			System.out.print(cs.getFreeVariables().size()+" ");
			System.out.println(cs.getFreeVariables());
			System.out.println();
			start=System.currentTimeMillis();
			for(int j=0; j<lecteur.dom.length; j++){
				start3=System.currentTimeMillis();
				cs.assignAndPropagate(lecteur.var[j], lecteur.dom[j]);
				System.out.println(cs.maxCost() +" " + cs.minCost());
				temps=System.currentTimeMillis()-start3;
				System.out.println(temps+"ms");
				cs.getFreeVariables();
				System.out.print(cs.getFreeVariables().size()+" ");
				System.out.println(cs.getFreeVariables());
			}
			temps=System.currentTimeMillis()-start;
			temps2=System.currentTimeMillis()-start2;
			System.out.println(i+"("+lecteur.dom.length+") "+temps+"ms "+temps2+"ms "+cs.isConfigurationComplete()+" "+cs.maxCost()+" "+cs.minCost());
			nbactions+=lecteur.dom.length;
			sum+=temps;
			sum2+=temps2;
			
		//}*/
		
				String var, val;
				
				var="v8";
				val="0";
				cs.isPresentInCurrentDomain(var, val);
				cs.assignAndPropagate(var, val);
				System.out.println(var+"="+val+" ["+cs.maxCost() +" " + cs.minCost()+"]");
				System.out.println(cs.getFreeVariables());
				System.out.println();
				cs.isConfigurationComplete();

				var="v27_1_Option";
				val="99";
				cs.isPresentInCurrentDomain(var, val);
cs.assignAndPropagate(var, val);
				System.out.println(var+"="+val+" ["+cs.maxCost() +" " + cs.minCost()+"]");
				System.out.println(cs.getFreeVariables());
				System.out.println();
				cs.isConfigurationComplete();

				var="v66";
				val="1";
				cs.isPresentInCurrentDomain(var, val);
cs.assignAndPropagate(var, val);
				System.out.println(var+"="+val+" ["+cs.maxCost() +" " + cs.minCost()+"]");
				System.out.println(cs.getFreeVariables());
				System.out.println();
				cs.isConfigurationComplete();

				var="v40_1_OptionPack";
				val="1";
				cs.isPresentInCurrentDomain(var, val);
cs.assignAndPropagate(var, val);
				System.out.println(var+"="+val+" ["+cs.maxCost() +" " + cs.minCost()+"]");
				System.out.println(cs.getFreeVariables());
				System.out.println();
				cs.isConfigurationComplete();

				var="v26_4_Serie";
				val="1";
				cs.isPresentInCurrentDomain(var, val);
cs.assignAndPropagate(var, val);
				System.out.println(var+"="+val+" ["+cs.maxCost() +" " + cs.minCost()+"]");
				System.out.println(cs.getFreeVariables());
				System.out.println();
				cs.isConfigurationComplete();

				var="v26";
				val="2";
				cs.isPresentInCurrentDomain(var, val);
cs.assignAndPropagate(var, val);
				System.out.println(var+"="+val+" ["+cs.maxCost() +" " + cs.minCost()+"]");
				System.out.println(cs.getFreeVariables());
				System.out.println();
				cs.isConfigurationComplete();

				var="v79";
				val="0";
				cs.isPresentInCurrentDomain(var, val);
cs.assignAndPropagate(var, val);
				System.out.println(var+"="+val+" ["+cs.maxCost() +" " + cs.minCost()+"]");
				System.out.println(cs.getFreeVariables());
				System.out.println();
				cs.isConfigurationComplete();

				var="v2";
				val="3";
				cs.isPresentInCurrentDomain(var, val);
cs.assignAndPropagate(var, val);
				System.out.println(var+"="+val+" ["+cs.maxCost() +" " + cs.minCost()+"]");
				System.out.println(cs.getFreeVariables());
				System.out.println();
				cs.isConfigurationComplete();

				var="v112";
				val="99";
				cs.isPresentInCurrentDomain(var, val);
cs.assignAndPropagate(var, val);
				System.out.println(var+"="+val+" ["+cs.maxCost() +" " + cs.minCost()+"]");
				System.out.println(cs.getFreeVariables());
				System.out.println();
				cs.isConfigurationComplete();

				var="v16";
				val="2";
				cs.isPresentInCurrentDomain(var, val);
cs.assignAndPropagate(var, val);
				System.out.println(var+"="+val+" ["+cs.maxCost() +" " + cs.minCost()+"]");
				System.out.println(cs.getFreeVariables());
				System.out.println();
				cs.isConfigurationComplete();

				var="v82";
				val="1";
				cs.isPresentInCurrentDomain(var, val);
cs.assignAndPropagate(var, val);
				System.out.println(var+"="+val+" ["+cs.maxCost() +" " + cs.minCost()+"]");
				System.out.println(cs.getFreeVariables());
				System.out.println();
				cs.isConfigurationComplete();

				var="v85";
				val="0";
				cs.isPresentInCurrentDomain(var, val);
cs.assignAndPropagate(var, val);
				System.out.println(var+"="+val+" ["+cs.maxCost() +" " + cs.minCost()+"]");
				System.out.println(cs.getFreeVariables());
				System.out.println();
				cs.isConfigurationComplete();

				var="v90";
				val="2";
				cs.isPresentInCurrentDomain(var, val);
cs.assignAndPropagate(var, val);
				System.out.println(var+"="+val+" ["+cs.maxCost() +" " + cs.minCost()+"]");
				System.out.println(cs.getFreeVariables());
				System.out.println();
				cs.isConfigurationComplete();
				
				var="v100";
				val="99";
				cs.isPresentInCurrentDomain(var, val);
cs.assignAndPropagate(var, val);
				System.out.println(var+"="+val+" ["+cs.maxCost() +" " + cs.minCost()+"]");
				System.out.println(cs.getFreeVariables());
				System.out.println();
				cs.isConfigurationComplete();

				var="v114";
				val="0";
				cs.isPresentInCurrentDomain(var, val);
cs.assignAndPropagate(var, val);
				System.out.println(var+"="+val+" ["+cs.maxCost() +" " + cs.minCost()+"]");
				System.out.println(cs.getFreeVariables());
				System.out.println();
				cs.isConfigurationComplete();

				var="v107";
				val="99";
				cs.isPresentInCurrentDomain(var, val);
cs.assignAndPropagate(var, val);
				System.out.println(var+"="+val+" ["+cs.maxCost() +" " + cs.minCost()+"]");
				System.out.println(cs.getFreeVariables());
				System.out.println();
				cs.isConfigurationComplete();

				var="v116";
				val="0";
				cs.isPresentInCurrentDomain(var, val);
cs.assignAndPropagate(var, val);
				System.out.println(var+"="+val+" ["+cs.maxCost() +" " + cs.minCost()+"]");
				System.out.println(cs.getFreeVariables());
				System.out.println();
				cs.isConfigurationComplete();
				
				System.out.println("---------------");
				cs.isPresentInCurrentDomain("v62", "0");

				
				temps3=System.currentTimeMillis()-start3;
				start4=System.currentTimeMillis();

				System.out.println(System.currentTimeMillis()-start1+"ms");
				System.out.println(System.currentTimeMillis()-start2+"ms");
				System.out.println(System.currentTimeMillis()-start3+"ms");
				
				var="v107";
				cs.unassignAndRestore(var);
				//cs.assignAndPropagate(var, val);
				System.out.println(var+"="+val+" ["+cs.maxCost() +" " + cs.minCost()+"]");
				System.out.println(cs.getFreeVariables());
				System.out.println();
				cs.isConfigurationComplete();
				cs.isPresentInCurrentDomain("v62", "0");

				
				var="v114";
				cs.unassignAndRestore(var);
				//cs.assignAndPropagate(var, val);
				System.out.println(var+"="+val+" ["+cs.maxCost() +" " + cs.minCost()+"]");
				System.out.println(cs.getFreeVariables());
				System.out.println();
				cs.isConfigurationComplete();
				cs.isPresentInCurrentDomain("v62", "0");

				var="v82";
				cs.unassignAndRestore(var);
				//cs.assignAndPropagate(var, val);
				System.out.println(var+"="+val+" ["+cs.maxCost() +" " + cs.minCost()+"]");
				System.out.println(cs.getFreeVariables());
				System.out.println();
				cs.isConfigurationComplete();
				cs.isPresentInCurrentDomain("v62", "0");

				var="v100";
				cs.unassignAndRestore(var);
				//cs.assignAndPropagate(var, val);
				System.out.println(var+"="+val+" ["+cs.maxCost() +" " + cs.minCost()+"]");
				System.out.println(cs.getFreeVariables());
				System.out.println();
				cs.isConfigurationComplete();
				cs.isPresentInCurrentDomain("v62", "0");

				var="v8";
				cs.unassignAndRestore(var);
				//cs.assignAndPropagate(var, val);
				System.out.println(var+"="+val+" ["+cs.maxCost() +" " + cs.minCost()+"]");
				System.out.println(cs.getFreeVariables());
				System.out.println();
				cs.isConfigurationComplete();
				cs.isPresentInCurrentDomain("v62", "0");

				var="v90";
				cs.unassignAndRestore(var);
				//cs.assignAndPropagate(var, val);
				System.out.println(var+"="+val+" ["+cs.maxCost() +" " + cs.minCost()+"]");
				System.out.println(cs.getFreeVariables());
				System.out.println();
				cs.isConfigurationComplete();
				cs.isPresentInCurrentDomain("v62", "0");

				var="v116";
				cs.unassignAndRestore(var);
				//cs.assignAndPropagate(var, val);
				System.out.println(var+"="+val+" ["+cs.maxCost() +" " + cs.minCost()+"]");
				System.out.println(cs.getFreeVariables());
				System.out.println();
				cs.isConfigurationComplete();
				cs.isPresentInCurrentDomain("v62", "0");

				var="v16";
				cs.unassignAndRestore(var);
				//cs.assignAndPropagate(var, val);
				System.out.println(var+"="+val+" ["+cs.maxCost() +" " + cs.minCost()+"]");
				System.out.println(cs.getFreeVariables());
				System.out.println();
				cs.isConfigurationComplete();
				cs.isPresentInCurrentDomain("v62", "0");

				var="v40_1_OptionPack";
				cs.unassignAndRestore(var);
				//cs.assignAndPropagate(var, val);
				System.out.println(var+"="+val+" ["+cs.maxCost() +" " + cs.minCost()+"]");
				System.out.println(cs.getFreeVariables());
				System.out.println();
				cs.isConfigurationComplete();
				cs.isPresentInCurrentDomain("v62", "0");

				var="v2";
				cs.unassignAndRestore(var);
				//cs.assignAndPropagate(var, val);
				System.out.println(var+"="+val+" ["+cs.maxCost() +" " + cs.minCost()+"]");
				System.out.println(cs.getFreeVariables());
				System.out.println();
				cs.isConfigurationComplete();
				cs.isPresentInCurrentDomain("v62", "0");

				var="v26";
				cs.unassignAndRestore(var);
				//cs.assignAndPropagate(var, val);
				System.out.println(var+"="+val+" ["+cs.maxCost() +" " + cs.minCost()+"]");
				System.out.println(cs.getFreeVariables());
				System.out.println();
				cs.isConfigurationComplete();
				cs.isPresentInCurrentDomain("v62", "0");

				var="v66";
				cs.unassignAndRestore(var);
				//cs.assignAndPropagate(var, val);
				System.out.println(var+"="+val+" ["+cs.maxCost() +" " + cs.minCost()+"]");
				System.out.println(cs.getFreeVariables());
				System.out.println();
				cs.isConfigurationComplete();
				cs.isPresentInCurrentDomain("v62", "0");

				var="v27_1_Option";
				cs.unassignAndRestore(var);
				//cs.assignAndPropagate(var, val);
				System.out.println(var+"="+val+" ["+cs.maxCost() +" " + cs.minCost()+"]");
				System.out.println(cs.getFreeVariables());
				System.out.println();
				cs.isConfigurationComplete();
				cs.isPresentInCurrentDomain("v62", "0");

				var="v112";
				cs.unassignAndRestore(var);
				//cs.assignAndPropagate(var, val);
				System.out.println(var+"="+val+" ["+cs.maxCost() +" " + cs.minCost()+"]");
				System.out.println(cs.getFreeVariables());
				System.out.println();
				cs.isConfigurationComplete();
				cs.isPresentInCurrentDomain("v62", "0");

				var="v26_4_Serie";
				cs.unassignAndRestore(var);
				//cs.assignAndPropagate(var, val);
				System.out.println(var+"="+val+" ["+cs.maxCost() +" " + cs.minCost()+"]");
				System.out.println(cs.getFreeVariables());
				System.out.println();
				cs.isConfigurationComplete();
				cs.isPresentInCurrentDomain("v62", "0");

				temps4=System.currentTimeMillis()-start4;

				
				System.out.println(temps1+"ms");
				System.out.println(temps2+"ms");
				System.out.println(temps3+"ms");
				System.out.println(temps4+"ms");

				
				/*v23=1
				v55=0
				v29_0_Serie=1
				v25=1
				v12=1
				v13=0

				2) It's conflict : v50=0

				3) Restore Value step :
				v29_0_Serie=1*/
		

		//System.out.println(cs.maxCost());
		//System.out.println(cs.minCost());

//System.out.println("---");
//System.out.println(sum+"ms");
//System.out.println(sum2+"ms");
//System.out.println(nbactions+" actions");

		
	}
}
/*
public class Main {



	
	public static void main(String[] args) {
		
		boolean arg_err=false;
		String arg_FichierACompiler = "";
		boolean arg_plus=true;
		int arg_heuristique=0;
		String arg_formefinale="";
		String arg_FichierSortie="";
		boolean flag_fichierSortie=false;
		boolean flag_beg=false;
		
		args=new String[4];
		args[0]="hbigPrices";
		args[1]="+";
		args[2]="3";
		args[3]="AADD";
		//args[4]="a";
		//args[5]="noskip";

		
		if(args.length<2 || args.length>6){
			System.out.println("too few or too many arguments");
			System.exit(0);
		}
		
		//file
		arg_FichierACompiler=args[0];
		
		//type
		if(args[1].compareTo("plus")==0 || args[1].compareTo("time")==0 || args[1].compareTo("p")==0 || args[1].compareTo("t")==0 || args[1].compareTo("+")==0 || args[1].compareTo("*")==0){
			if (args[1].compareTo("time")==0 || args[1].compareTo("t")==0 || args[1].compareTo("*")==0 )
				arg_plus=false;
		}else{
			arg_err=true;
			System.out.println("erreur :  argument 2 doit etre \"plus\" ou \"time\" ");
		}
		
		//heuristic
		if(args.length>2){
			try {
				arg_heuristique=Integer.parseInt(args[2]);
				if (arg_heuristique>10 || arg_heuristique<0){
					arg_err=true;
					System.out.println("erreur :  argument 3 (x) doit etre un nombre compris entre 0 et 10");
				}
			} catch (NumberFormatException e) {
				arg_err=true;
				System.out.println("erreur :  argument 3 (x) doit etre un nombre");
			}
		}else{
			arg_heuristique=3;
		}

		if(args.length>3){
			arg_formefinale=args[3];
			if(!(arg_formefinale.contains("AADD") || arg_formefinale.contains("SLDDp") || arg_formefinale.contains("SLDDt") || arg_formefinale.contains("ADD")) ){
				arg_err=true;
				System.out.println("erreur : forme final (" + args[3] + ") non accepté. possibilités : AADD, SLDDp, SLDDt, ADD");
			}
		}else{
			arg_formefinale="prout";
		}
		
		if(args.length>4){
			flag_fichierSortie=true;
			arg_FichierSortie=args[4];
		}
		
		if(args.length>5){
			if(args[5].compareToIgnoreCase("NoSkip")==0){
				flag_beg=true;
			}
		}
		
		
		if(arg_err){
			System.out.println("programme interompu");
			System.exit(0);
		}	
		
		CompilateurSLDD cs;
		cs=new CompilateurSLDD(null);

		cs.compilation(args[0], arg_plus, arg_heuristique, arg_formefinale, arg_FichierSortie, flag_fichierSortie, flag_beg);
		
		
	}
}*/


