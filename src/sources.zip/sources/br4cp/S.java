package br4cp;

import java.util.ArrayList;


public class S extends Structure{

	public S(){
		super();
	}
	
	public Structure copie(){
		Structure s=new Structure();
		return s;
	}
	
	public void operation(S str){
		//nadau
	}
	
	public void initOperation(Structure str, Structure str2){
		//vive le bearn libre
	}
	
	public S normaliseInf(ArrayList<S> liste){
		return new S();
	}
	
	public void normaliseSup(ArrayList<S> liste, S remonte){
		//yalalheeeeee
	}
	
	public void normaliseSup(S str, Spt remonte){
		//yalalheeeeee
	}
	
	public boolean isNeutre(){
		return true;
	}
	
	public boolean min(Structure comp1, Structure comp2){
		System.out.println("@Structure : non applicable");
		return false;
	}
	
	public boolean max(Structure comp1, Structure comp2){
		System.out.println("@Structure : non applicable");
		return false;
	}
	
	public boolean isabsorbant(){
		return false;
	}
	
	public void toNeutre(){
	}
	
	
	public String toDot(){
		return "";
	}
	
	public String toTxt(){
		return "";
	}
	
	public int hashCode(){
		return 0;
	}
	
	public boolean equals(S comp){
		System.out.println("b");
		return true;
	}
	
	public boolean inaccessible(){
		System.out.println("@Structure : cas a revoir");
		return false;
	}
	
	public void rendreInaccessible(){
		System.out.println("@Structure : cas a revoir");
	}
	
	public double getvaldouble(){
		return 0;
	}
	
}
