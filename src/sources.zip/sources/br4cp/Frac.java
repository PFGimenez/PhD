package br4cp;


public class Frac {
	long d,n;
	
	public Frac(long nume, long deno){
		n=nume;
		d=deno;
		
		reduce();
		
	}
	
	public Frac add(Frac f){
		
		Frac res=new Frac(1,1);
		
		res.n=d*f.n+n*f.d;
		res.d=d*f.d;
		
		res.reduce();
		
		return res;
	}
	
	public Frac mult(Frac f){

		Frac res=new Frac(1,1);
		
		res.d=d*f.d;
		res.n=n*f.n;
		
		res.reduce();
		
		return res;
	}
	
	public Frac sous(Frac f){

		
		Frac res=new Frac(1,1);
		
		res.n=n*f.d-d*f.n;
		res.d=d*f.d;
		
		res.reduce();
		
		return res;
	}
	
	public Frac div(Frac f){

		
		Frac res=new Frac(1,1);
		
		res.d=d*f.n;
		res.n=n*f.d;
		
		res.reduce();
		
		return res;
	}
	
	public Frac max(Frac f){
		Frac res=new Frac(1,1);
		
		if((double)n/d < (double)f.n/f.d ){
			res.d=f.d;
			res.n=f.n;
		}else{
			res.d=d;
			res.n=n;
		}
		
		return res;
	}
	
	public Frac min(Frac f){
		Frac res=new Frac(1,1);
		
		if((double)n/d > (double)f.n/f.d ){
			res.d=f.d;
			res.n=f.n;
		}else{
			res.d=d;
			res.n=n;
		}
		
		return res;
	}
	
	public long pgcd(){
		long a,b,c;
		
		if(d==0 || n==0)
			return 1;
		
		if(d>n){
			a=d; b=n;
		}else{
			a=n; b=d;
		}
		
		while (a!=1 && b!=1){
			if(a%b==0)
				return b;
			else{
				c=a%b;
				a=b;
				b=c;
			}
		}
		return 1;
	}
	
	public void reduce(){
		if (d<-1 || n<-1){
			System.out.println("@frac : depasse long n="+n+" d="+d);
		}
		
		if(n==0){
			d=1;
		}
		
		
		long a;
		
		a=pgcd();
		while(a!=1){
			n=n/a;
			d=d/a;
			a=pgcd();
		}
	}
	
	public double val(){
		return (double)n/d;
	}
	
	public boolean equal(Frac f){
		if(f.d==d && f.n==n)
			return true;
		else
			return false;
	}
	
	public String ts(){
		return(n+"/"+d);
	}
	
	public Frac copie(){
		return new Frac(n, d);
	}
}
