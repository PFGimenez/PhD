package br4cp;

/*   (C) Copyright 2013, Schmidt Nicolas
 * 
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.util.ArrayList;

import java.awt.List;
import java.io.FileWriter;
//import java.io.FileReader;
//import java.io.File;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class VDD {
	
	static int indice;
	
	final boolean COMB_UP=true;
	final boolean COMB_DOWN=false;
		
	ArrayList <Var> variables;
	
//    protected NodeDD first;							//the one first node (si plusieurs, creer plusieurs 
    protected Arc first;
    public NodeDDlast last;
    
//    protected UniqueTable ut;			//ensemble des neuds
    protected UniqueHashTable uht;			//ensemble des neuds
    
	protected boolean flagPlus=true;			//(plus,mult) add : false,false; sldd+ : true,false; sldd* : false,true; aadd : true,true
	protected boolean flagMult=false;
	
	public boolean flagOperateurPrincipalMultiplication=false;
	
	static int cptdot=0;
	
	protected Structure min=null, max=null;

// constructeur
/*    public VDD(){
		lasts=new ArrayList<NodeDD>();
		ut=new UniqueTable();
    }
    
	public VDD(NodeDD start){
		lasts=new ArrayList<NodeDD>();
		ut=new UniqueTable();
		
	    first=start;
	    ut.add(first);
	}
	
    public VDD(UniqueTable u){
		lasts=new ArrayList<NodeDD>();
		ut=u;
    }
    
	public VDD(UniqueTable u, NodeDD start){
		lasts=new ArrayList<NodeDD>();
		ut=u;
		
	    first=start;
	    ut.add(first);
	}*/
    //creation class VDD a partir de lecture de fichier
    public VDD(Arc a,UniqueHashTable u, ArrayList<Var> v){
		uht=u;
		first=a;
		variables=v;
		last=new NodeDDlast();
    } 
    
    //pour le add
    public VDD(UniqueHashTable u){
    	uht=u;
    }
	
    //cree un DD de 1 variable non bool a partir d'une UT existante
/*    public VDD(Var var, UniqueHashTable u){
		uht=u;
		variables=new ArrayList<Var>();
		
		NodeDD tete=new NodeDD(var, 0);
		first=new Arc(tete, 0);
		
		ut.add(tete);
		variables.add(var);
		
		for(int i=0; i<var.domain; i++)
			new Arc(tete, ut.getzero(), i);
    }*/ 
    
 
  //cree un DD de x variable
    public VDD(ArrayList<Var> liste, UniqueHashTable u, boolean plus){
		uht=u;
		variables=liste;
		last=new NodeDDlast();
		Structure s;
		
		NodeDD tete=new NodeDD(variables.get(0));
		first=new Arc(tete, plus);
//		uht.add(tete);
		
		NodeDD precedant;
		precedant=tete;
		
		for(int i=1; i<variables.size(); i++){				//on ajoute chaque neud, avec un lien, avec n arcs
			NodeDD suivant=new NodeDD(variables.get(i));		//neuds : variable de 1 a x
			for(int j=0; j<variables.get(i-1).domain; j++){		//domaine : de 0 a x-1
				if(plus)
					s=new Sp();
				else
					s=new St();
				new Arc(precedant, suivant, j, s);		//int donc SLDD+
			}
			uht.add(precedant);	
			precedant=suivant;
		}
		
		
		for(int j=0; j<variables.get(variables.size()-1).domain; j++){		//on ajoute les feuilles au dernier
			if(plus)
				s=new Sp();
			else
				s=new St();
			new Arc(precedant, last, j, s);
		}
		uht.add(precedant);
		uht.add(last);
		

		
    } 
    //operation de deux VDD
/*    public VDD(VDD a, VDD b, UniqueHashTable u){
		boolean plus=true;
    	uht=u;
		variables=a.variables;
		last=new NodeDDlast();
		Structure s;
		
		NodeDD tete=new NodeDD(variables.get(0));
		first=new Arc(tete, plus);						//todo
//		uht.add(tete);
		
		NodeDD precedant;
		precedant=tete;
		
		for(int i=1; i<variables.size(); i++){				//on ajoute chaque neud, avec un lien, avec n arcs
			NodeDD suivant=new NodeDD(variables.get(i));		//neuds : variable de 1 a x
			for(int j=0; j<variables.get(i-1).domain; j++){		//domaine : de 0 a x-1
				if(plus)
					s=new Sp();
				else
					s=new St();
				new Arc(precedant, suivant, j, s);		//int donc SLDD+
			}
			uht.add(precedant);	
			precedant=suivant;
		}
		
		
		for(int j=0; j<variables.get(variables.size()-1).domain; j++){		//on ajoute les feuilles au dernier
			if(plus)
				s=new Sp();
			else
				s=new St();
			new Arc(precedant, last, j, s);
		}
		uht.add(precedant);
		uht.add(last);
    	
    	this.first.s.initOperation(a.first.s, b.first.s);
    	this.first.fils.copie.add(a.first.fils);
    	this.first.fils.copie.add(b.first.fils);				//pas besoin de suppr ce noeud pour tout ca
    	
    	
    	this.add(a, b, 1);
    	
    	uht.copieToNull();
    	uht.normaliser();   	
 	}*/
    
    
    
    
//methodes
 

    
    //risque d'explosion !!!!
    //recursif descend les valeurs sur les feuilles finales
    ////////////obsolete !!!!!//////////////////
    /*public void combDown(NodeDD curr){			//peigne vers le bas

    	curr.cpt=0;												//neud utile, on le garde
    	
    	for(int i=0; i<curr.kids.size(); i++){
    		if ((curr.value + curr.kids.get(i).getVal())>0){		//si une valeure a descendre 
    			NodeDD nouveau = new NodeDD(curr.kids.get(i).fils, curr.kids.get(i), (curr.value + curr.kids.get(i).getVal()) );	// on en cree un nouveau, avec la nouvelle valeure en plus. le nouveau remplace l'ancien dans l'arc
    			
    			//test si deja existant
    			int existeDeja=ut.recherche(nouveau);
    			if(existeDeja!=-1){			//alors il exite deja
    				nouveau=ut.get(nouveau.variable, existeDeja);
    				curr.kids.get(i).changerFils(nouveau);
    			}else{
    				ut.add(nouveau);
    			}
    		}											
    		
			curr.kids.get(i).setVal(0);					//plus de valeur sur l'arc
			
			//if (!curr.kids.get(i).fils.isLeaf()){
			//	descendreValeurs(curr.kids.get(i).fils);		// la suite !
			}
    	for(int i=0; i<curr.kids.size(); i++){
    		if (!curr.kids.get(i).fils.isLeaf()){
    			combDown(curr.kids.get(i).fils);
    		}else{
    			curr.kids.get(i).fils.cpt=0;
    		}
    	}
    		
    	curr.value=0;
    	
    }*/
    
    // attention si poids negatifs : conflits sur cpt (cpt:indicateur, cpt=-1:suppression)
    //recursif descend les valeurs sur les feuilles finales (gestion des arcs)

/*    public void combDown(Arc curr){			//peigne vers le bas
    	
    	Structure valAmont=curr.s;
    	boolean aDevelopper=true;
    	NodeDD currNode=curr.fils;
    	uht.removeFromTable(curr.fils);
    	    	
    	if (!currNode.isLeaf()) {						//cas pas feuille  		
    		
			if (!valAmont.isNeutre()) { //si une valeure a descendre
				for(int i=0; i<currNode.structcopie.size(); i++){ //on parcourt la liste chainee dynamique des copies...
					if (currNode.structcopie.get(i).equals(valAmont)){ //si on trouve la bonne, ya good.  (+cptcurr car si une valeur a deja ete atribue, il faut pas non plus l'oublier vu qu'on l'a deja compte pour la suite
						aDevelopper = false;
						curr.changerFils(currNode); //nouveau chemin
						curr.s.toNeutre(); //chemin amont a 0
						break;
					}
				}
			} else {
				if (currNode.cpt >= 0) //on est deja passé par la
					aDevelopper = false;
			}
			if (aDevelopper) { //pas de racourcit
				if (!valAmont.isNeutre()) { //nouvelle copie
					NodeDD nouveau = new NodeDD(curr.fils, curr); 
					curr.fils.structcopie.add(valAmont);							//cpt=indicateur !!
					curr.fils.copie.add(nouveau);
					nouveau.cpt=0;								// je sais pas si c'est utile, on est jamais trop prudent
					//uht.add(nouveau);
					curr.changerFils(nouveau);
					for (int i = 0; i < nouveau.kids.size(); i++) {
						nouveau.kids.get(i).s.operation(valAmont); //on descend le poid.
					}
					curr.s.toNeutre(); //on supprime l'ancien
				} else { //developpement classique
					currNode.cpt = 0; //et le neud restera
				}

				//pour les deux
				for (int i = 0; i < curr.fils.kids.size(); i++)
					combDown(curr.fils.kids.get(i));
			}
		}else{											///cas feuille
			if(!valAmont.isNeutre()){								//cas ou ya qqch a faire
				NodeDD nouveau = new NodeDD(curr.fils, curr);
				for(int i=0; i<nouveau.kids.size(); i++)
					nouveau.kids.get(i).operationS(valAmont);
				

				curr.changerFils(nouveau);
				curr.s.toNeutre();
			}
			curr.fils.cpt=0;
		}
    }*/
    
/*    public void combDownMult(Arc curr){			//peigne vers le bas
    	 
    	double coefAmont=curr.coef;
    	    	
    	boolean aDevelopper=true;
    	
    	NodeDD currNode=curr.fils;
    	
    	if (!currNode.isLeaf()) {						//cas pas feuille
			if (coefAmont != 1) { //si coef != 1
				while (!currNode.copie.isEmpty()) { //on parcourt la liste chainee dynamique des copies...
					currNode = currNode.copie.get(0);
					if (currNode.memoire == coefAmont){ //si on trouve la bonne, ya good.  (+cptcurr car si une valeur a deja ete atribue, il faut pas non plus l'oublier vu qu'on l'a deja compte pour la suite
						aDevelopper = false;
						curr.changerFils(currNode); //nouveau chemin
						curr.setCoef(1);
						break;
					}
				}
			} else {
				if (currNode.cpt >= 0) //on est deja passé par la
					aDevelopper = false;
			} 
			if (aDevelopper) { //pas de racourcit
				if (coefAmont!=1) { //nouvelle copie
					NodeDD nouveau = new NodeDD(curr.fils, curr, 0); 
					nouveau.memoire = coefAmont;			//cpt=indicateur !!
					nouveau.cpt=0;								// je sais pas si c'est utile, on est jamais trop prudent
					ut.add(nouveau);
					if(currNode.copie.isEmpty())
						currNode.copie.add(nouveau);
					else
						currNode.copie.set(0, nouveau);
					curr.changerFils(nouveau);
					for (int i = 0; i < nouveau.kids.size(); i++) {
						nouveau.kids.get(i).multCoef(coefAmont); //on descend le poid.
					}
					curr.setCoef(1); //chemin amont a 1 (element neutre)
				} else{			//si on a pas eu besoin de creer un nouveau
					currNode.cpt = 0; //et le neud restera
				}


				//pour les deux
				for (int i = 0; i < curr.fils.kids.size(); i++)
					combDownMult(curr.fils.kids.get(i));
			}
		}else{											///cas feuille
			if(coefAmont != 1){								//cas ou ya qqch a faire
				NodeDD nouveau = new NodeDD(ut.getzero(), curr, coefAmont);
				int indice=ut.recherche(nouveau);
				if(indice!=-1){
					nouveau=ut.get(0, indice);
				}else{
					ut.add(nouveau);
				}
				curr.changerFils(nouveau);
				curr.setCoef(1); //chemin amont a 1 (element neutre)
				
			}
			curr.fils.cpt=0;
		}
    }*/
    
    //recursif remonte les valeurs sur les neuds et arcs
/*    public void combUp(NodeDD curr){
    	curr.cpt=1;
    	int min=0;
    	boolean ok=false;
    	
    	if(!curr.isLeaf()){
			
			for(int i=0; i<curr.kids.size(); i++){
				if(curr.kids.get(i).fils.cpt==0)
					combUp(curr.kids.get(i).fils);
			}

			curr.remonterValeur();		//arc inf vers arc sup
    	}
    }*/
    
    //recursif remonte les valeurs sur les arcs => slddmult
/*    public void combUpMult(NodeDD curr){

    	curr.cpt=1;
    	double max=-1000000;		//fraction max
    	
    	if(!curr.isLeaf()){
			
			for(int i=0; i<curr.kids.size(); i++){
				if(curr.kids.get(i).fils.cpt==0)
					combUpMult(curr.kids.get(i).fils);
			}


			for(int i=0; i<curr.kids.size(); i++){							
				if (curr.kids.get(i).bottom==0 &&
					curr.kids.get(i).getCoef()>max){
						max=curr.kids.get(i).getCoef();			//on recupere le max
				}
			}
			if(max==-1000000){			//si il n'y a pas d'arc sans bottom
				curr.bottom=curr.kids.get(0).bottom;
			}
			else{
				for(int i=0; i<curr.fathers.size(); i++){
					curr.fathers.get(i).multCoef(max);
				}
				for(int i=0; i<curr.kids.size(); i++){
					if(curr.kids.get(i).bottom==0)
						curr.kids.get(i).divCoef(max);
				}
			}
    	}    	
    }*/
    
/*    public void comb(){
    	if(flagPlus==true && flagMult==false){		//sldd+
    		combUp(this.first.fils);
    		uht.cptTo(0);
    	}
    	
    	if(flagPlus==false && flagMult==false)	{	//add
    	ut.cptTo(-1);
    		
    	combDown(this.first);
    		
    	ut.copieToNull();
    	ut.supprNeudNegatifs();
    	ut.valNodesToZero(false);
		ut.cptTo(0);
		//a t'on reelement besoin du 0
//		if(ut.getzero().fathers.size()==0){
//			ut.remove(ut.getzero());
//		}

    	}
    	
    	if(flagPlus==true && flagMult==true)	{	//aadd
    	ut.cptTo(0);
    	recurSlddToAadd(this.first.fils);
    	ut.cptTo(0);
    	ut.valueTo(0);
    	}
    	
    	if(flagPlus==false && flagMult==true){		//sldd*
    		combUpMult(this.first.fils);
    		ut.cptTo(0);
    	}
    }*/
    
    // ras
/*    public void slddToAdd(){
    	flagPlus=false;
    	comb();
    }*/
    
/*    public void slddMultToAdd(){
    	flagMult=false;
    	
    	//mettre les neux finaux a 0 au lieu de 1
    	
    	ut.cptTo(-1);
		
    	combDownMult(this.first);
    		
    	ut.copieToNull();
    	ut.supprNeudNegatifs();
		ut.cptTo(0);
		ut.memoireTo(1);
		
		//a t'on reelement besoin du 0
//		if(ut.getzero().fathers.size()==0){
//			ut.remove(ut.getzero());
//		}
		
    }*/
    
    
/*    public void addToSldd(){
    	flagPlus=true;
    	comb();
    }*/
    
    public void slddToAadd(){
 //   	if(flagPlus==false)
//    		this.addToSldd();
    	flagMult=true;

    	//init 
    	Spt nouv=new Spt(((Sp)first.s).getVal(), 1);
		first.s=nouv;
    	
    	uht.SpToSpt();

    	//uht.testStructureUniforme();
		
    	uht.normaliser();

    }
    
    
    public void slddMultToAadd(){
    	 //   	if(flagPlus==false)
//    	    		this.addToSldd();
    	    	flagMult=true;
    	    	flagPlus=true;

    	    	//init 
    	    	Spt nouv=new Spt(0, ((St)first.s).getvaldouble());
    			first.s=nouv;
    	    	
    	    	uht.StToSpt();

    	    	//uht.testStructureUniforme();
    			
    	    	uht.normaliser();

    	    }
    
/*    public void slddMultToAadd(){
    	if(flagMult==false)
    		this.addToSlddMult();
    	flagPlus=true;
    	
    	//init
    	for(int i=0; i<ut.getzero().fathers.size(); i++){
    		ut.getzero().fathers.get(i).setVal(ut.getzero().fathers.get(i).getCoef());
    		ut.getzero().fathers.get(i).setCoef(0);
    	}
    	   	
    	comb();   	
    }*/

/*    public void addToSlddMult(){
    	flagPlus=false;
    	flagMult=true;
    	
    	//remonter les valeurs finales sur les arcs
    	for(int i=0; i<ut.get(0).size(); i++){
    		for(int j=0; j<ut.get(0, i).fathers.size(); j++){
    			ut.get(0, i).fathers.get(j).coef=ut.get(0, i).value;
    		}
			ut.get(0, i).value=1;
    	}
    	
    	comb();
    }
    */
    //recursif introduit des coefficients multiplicateurs. valeurs normalisés
/*    public void recurSlddToAadd(NodeDD curr){
    	curr.cpt=1;
    	double max=-1000000;
    	double min= 1000000;
    	double range=0;
    	
    	if(!curr.isLeaf()){
			
			for(int i=0; i<curr.kids.size(); i++){
				if(curr.kids.get(i).fils.cpt==0)
					recurSlddToAadd(curr.kids.get(i).fils);
			}

			for(int i=0; i<curr.kids.size(); i++){
				if (curr.kids.get(i).bottom==0 &&
					curr.kids.get(i).getVal()+curr.kids.get(i).getCoef()>max)  {
						max=curr.kids.get(i).getVal() + curr.kids.get(i).getCoef();		// max prend la plus grande somme v/d,n/d
				}
				
				if (curr.kids.get(i).bottom==0 &&
					curr.kids.get(i).getVal()<min ){
							min=curr.kids.get(i).getVal();
					   }
			}
			
			if(max!=-1000000 && min!=1000000){
				range=max-min;
				
				for(int i=0; i<curr.kids.size(); i++){
					curr.kids.get(i).addVal(-min);				//on soustrait le min a tous
					curr.kids.get(i).divVal(range);		//on divise les deux par range
					curr.kids.get(i).divCoef(range);
				}
				
				min*=range;		//on va tout additionner par (min*range), donc la c'est fait !!
				for(int i=0; i<curr.fathers.size(); i++){
					curr.fathers.get(i).addVal(min);			//on soustrait le min a tous
					curr.fathers.get(i).multCoef(range);
				}
				
				
			}else{
				System.out.println("err@VDD : neud dont tous les fils valent 0");
			}

    	}
    	
    }*/
    
    //reduction (ne supprime pas les neuds innutiles
/*    public void contract(){
    	//toremove
    	//ut.cptTo(0);
    	
    	//on on arrondi si on est en ADD
    	if(!flagMult && !flagPlus){
    		if(testplus_testtime()){	//si on est en mode +
    			ut.addToInt();    			
    		}
    	}
    	
        ArrayList<NodeDD> liste = new ArrayList<NodeDD>();
        NodeDD curr, comp;
        //init
        for(int i=0; i<ut.size(0); i++)
        	liste.add(ut.get(0, i));


        //debut
        for(int var=ut.nbVariables; var>0; var--){

        	for(int i=0; i<liste.size(); i++){
                curr=liste.get(i);
                for(int j=i+1; j<liste.size(); j++){    //test si similaires
                    comp=liste.get(j);
     
                    if(curr.compare(comp)){     //si equivalents
                        curr.fusion(comp);
                        ut.remove(comp);	//on supprime de tabNodes
                        liste.remove(j);									//puis de liste (optionel?)
                        j--;                   //sinon on sautera le test du suivant :(
                    }
                    
                }
            }
            
            //mise a jours de la liste
            liste.clear();
            for(int i=0; i<ut.size(var); i++)
            	liste.add(ut.get(var, i));
        }
        //rechercheNoeudInutile();    //bien fait cette bande de PARASITES !!!!

        //on suprime tous les neuds inutiles
        ut.supprNeudNegatifs();
        ut.cptTo(0);
    }*/
    
/*    //reduction (ne supprime pas les neuds innutiles
    //(2) s'assure qu'il n'y a pas une copie qui pointe vers lui
    public void contract2(int start){
    	//toremove
    	ut.cptTo(0);
    	
    	//on on arrondi si on est en ADD
    	if(!flagMult && !flagPlus){
    		if(testplus_testtime()){	//si on est en mode +
    			ut.addToInt();    			
    		}
    	}
    	
        ArrayList<NodeDD> liste = new ArrayList<NodeDD>();
        NodeDD curr, comp;
        //init
        for(int i=0; i<ut.size(0); i++)
        	liste.add(ut.get(0, i));


        //debut
        for(int var=start; var>0; var--){

        	for(int i=0; i<liste.size(); i++){
                curr=liste.get(i);
                for(int j=i+1; j<liste.size(); j++){    //test si similaires
                    comp=liste.get(j);
     
                    if(curr.compare(comp)){     //si equivalents
                        curr.fusion(comp);
                        comp.cpt=1;
                        for(int k=0; k<ut.size(var); k++){
                        	for(int l=0; l<ut.get(var, k).copie.size(); l++){
                        		if(ut.get(var, k).copie.get(l).cpt==1){
                        			ut.get(var, k).copie.set(l, curr);
                        			System.out.println("plop");
                        		}
                        	}
                        }
                        ut.cptTo(0);
                        ut.remove(comp);	//on supprime de tabNodes
                        liste.remove(j);									//puis de liste (optionel?)
                        j--;                   //sinon on sautera le test du suivant :(
                    }
                    
                }
            }
            
            //mise a jours de la liste
            liste.clear();
            for(int i=0; i<ut.size(var); i++)
            	liste.add(ut.get(var, i));
        }
        //rechercheNoeudInutile();    //bien fait cette bande de PARASITES !!!!

        //on suprime tous les neuds inutiles
        ut.supprNeudNegatifs();
        //ut.cptTo(0);
    }*/
    
/*    public void ajoutDefaultCost(double[] constraint, double defaultCost, boolean softConstraint){
    	// get last variable
    	int lastvariable=0;
    	if( !softConstraint ||
    		(( defaultCost!=0 && !flagOperateurPrincipalMultiplication) ||
    	   // ( defaultCost!=1 && flagOperateurPrincipalMultiplication) ) ){
    		( false ) ) ){
    		for(int i=(constraint.length-1); i>0; i--){
    			if(constraint[i]!=-1){
    				lastvariable=i;
    				break;
    			}
    		}
    	
	    	ArrayList<NodeDD> liste;
	    	liste=uht.get(lastvariable);
	    	
	    	for(int i=0; i<liste.size(); i++){
	    		for(int j=0; j<liste.get(i).kids.size(); j++){
	    			if(!softConstraint)
	    				liste.get(i).kids.get(j).bottom+=1;			//on increment le bottom, si il etait deja a 1, il reviendra pas a zero
	    			else{
	    				if(!flagOperateurPrincipalMultiplication)	//cas de l'adition en operateur principale du fichier d'entree
	    					liste.get(i).kids.get(j).addVal(defaultCost);
	    				else{										//cas de la multiplication...
	    					liste.get(i).kids.get(j).multCoef(defaultCost);
	    				}
	    			}
	    		}
	    	}
    	
    	}
    }*/
    
    
    //recursif (voir l'autre fonction du meme nom)
    public void valeurChemin(Arc arc, ArrayList<int[]> var, ArrayList<Structure> poid, ArrayList<Integer> id, boolean softConstraint, Structure defaultCost){    	  	
    	
    	boolean end=true;
    	
    	boolean dejavu=false;
    	NodeDD temp=arc.fils;

    	if(!arc.fils.isLeaf()){
    		//for(int i=arc.fils.variable.pos+1; i<var.get(0).length; i++){
	    	for(int i=arc.fils.variable.pos; i<var.get(0).length; i++){
	    		if(var.get(0)[i]!=-1){
	    			end=false;
	    			break;
	    		}
	    	}
    	}
    	
    	if(var.size()==0){
    		System.out.println("inutile");
    	}
    	
    	//on detecte si cette séquences est déjà passé par là
    	if(!end){
    		if(temp.cpt!=1){	
    			
		    	for(int i=0; i<temp.copie.size(); i++){
		    		if (temp.indcopie.get(i)==id.get(0)){		//si le 0 y est, tous les autres doivent suivre  &&  sauf si il a ete supprime
		    			if(temp.copie.get(i).cpt!=-1){
		    				arc.changerFils(temp.copie.get(i));
		    			}else{
		    				if(temp.copie.get(i).copie.size()!=0)
		    					arc.changerFils(temp.copie.get(i).copie.get(0)); 
		    				else
		    					//on pointe vers un truc a bottom en fait
		    					arc.bottom=1;
		    			}
		    			if(temp.fathers.size()==0){
		        			temp.cpt=-1;
		    			}
		    			dejavu=true;
		    			arc.operationValuerARemonter();
		    			break;
		    		}
		    	}
	    	}else{
	    		dejavu=true;
	    	}
    	}

    	
    	ArrayList<int[]> varnext= new ArrayList<int[]>();
    	ArrayList<Structure> poidnext= new ArrayList<Structure>();
    	ArrayList<Integer> idnext= new ArrayList<Integer>();
    	
    	if(!dejavu){
       		//on selectionne pour la suite
        	if(!end){			//si pas fini
	        	if(arc.fils.fathers.size()>1 &&
	            	!(arc.fils.isMonoPere() &&  var.get(0)[arc.fils.variable.pos-1]==-1)){	//dans ces cas on cree un nouveau sommet
	        		
	        		NodeDD nouv=new NodeDD(arc.fils, arc);
	        		nouv.cpt=1;
	        		temp.copie.add(nouv);
	        		temp.indcopie.add(id.get(0));
	        	}else{					//on en cree pas
					arc.fils.cpt=1;
	        		uht.removeFromTable(arc.fils);							//on l'enleve le temps des changements
	        		temp.copie.add(temp);
	        		temp.indcopie.add(id.get(0));
	        	}
    	
        		if(var.get(0)[temp.variable.pos]!=-1){						//cas ou la variable est instenciee
            		for(int i=0; i<temp.kids.size(); i++){
            			if(arc.fils.kids.get(i).bottom==0){		//on verifie que le fils n'est pas une feuille
            				varnext.clear();
            				poidnext.clear();
            				idnext.clear();
            				for(int j=0; j<var.size(); j++){
            					if((int)var.get(j)[temp.variable.pos]==i){		//on garde ceux qu'on va mettre ensemble
            						varnext.add(var.get(j));
            						poidnext.add(poid.get(j));
            						idnext.add(id.get(j));
//           						var.remove(j);
//            						id.remove(j);
//            						j--;
            					}
            				}
            				//ici on developpe ce groupe la
            				if (!varnext.isEmpty()){
            					valeurChemin(arc.fils.kids.get(i), varnext, poidnext, idnext, softConstraint, defaultCost);
            				}else{
            			    	if( !softConstraint){
            			    		arc.fils.kids.get(i).bottom++;
            			    	}else{
            			    		if(!defaultCost.isNeutre() && !flagOperateurPrincipalMultiplication){// ||
            			    			arc.fils.kids.get(i).operationS(defaultCost);
            			    		}
            					}
            				}

            			}
            		}
    			}else{
//    				ArrayList<NodeDD> aajouter=new
    				for(int i=0; i<arc.fils.kids.size(); i++){
        				if(arc.fils.kids.get(i).bottom==0){		//on verifie que le fils n'est pas une feuille
        					//copie de var->varnext
            				varnext.clear();
            				poidnext.clear();
            				idnext.clear();
        					for(int j=0; j<var.size(); j++){
        						varnext.add(var.get(j));
        						poidnext.add(poid.get(j));
        						idnext.add(id.get(j));
        					}
        					valeurChemin(arc.fils.kids.get(i), varnext, poidnext, idnext, softConstraint, defaultCost);
        				}
    				}
    			}
    		}else{				//si fini
    	    	
        		if(softConstraint){		 			//contrainte valuee
        			for(int i=0; i<poid.size(); i++){
 //       				if(poid.get(i).isabsorbant())
 //       					System.out.println("botom");
        				
        				arc.operationS(poid.get(i));
        				if(i>=1)
        					System.out.println("@VDD : coucou");
        			}

        		//	for(int j=0; j<var.size(); j++)
        		//			arc.fils.kids.get((int)var.get(j)[arc.fils.variable.pos]).s.operationSLDD(var.get(j)[0]);		//var[0]==poid
        		}//else{								//contrainte non valuee
        		//	for(int j=0; j<var.size(); j++){
        		//		arc.fils.kids.get((int)var.get(j)[arc.fils.variable.pos]).bottom-=1;		//on decremente le botom (si 1, alors il devien zero et fini) 
        		//	}
        		//}
         	}
        	
        	if(!arc.fils.isLeaf())
        		uht.ajoutNormaliseReduitPropage(arc.fils);

        }
    	
    	
    }
    
    //permet de rentrer un poid specifique a un chemin
    // [ poid0, contrainte0..]
    // [ poid1, contrainte1..]
    public void valeurChemin(int[][] var, Structure[] poids, Structure defaultCost, boolean softConstraint){
    //cout par defaut//
    	// get last variable  
    	
    	int lastvariable=0;
    	ArrayList<NodeDD> liste=null;

    	
    	int firstC=-1;
    	for(int i=1; i<var[0].length; i++){
    		if(var[0][i]!=-1){
    			firstC=i;
    			break;
    		}
    	}
    	
    	//transpho des donnes en arraylist
    	ArrayList<int[]> varliste= new ArrayList<int[]>();
    	ArrayList<Structure> poidliste= new ArrayList<Structure>();
    	ArrayList<Integer> varlistind=new ArrayList<Integer>();
    	
    	for(int i=0; i<var.length; i++){
    		varlistind.add(i);
    		varliste.add(var[i]);
    		poidliste.add(poids[i]);
    	}
 
    	
    	if(varliste.size()>0){
    		//sauvegarde des departs (on ne peut pas lire une hashtable qu'on modifie)
    		//NodeDD[] tableNode=new NodeDD[uht.size(firstC)];
    		ArrayList<NodeDD> tableNode;
    		tableNode=uht.get(firstC);
   

    		
    		//on supprime les fathers pour pouvoir modifier les fils tranquil
    		//NodeDD[] fathers;
    		ArrayList<NodeDD> fathers;
    		//if(firstC!=1){
    		//	fathers=new NodeDD[uht.size(firstC-1)];
    		//}else{
    		//	fathers=new NodeDD[0];
    		//}
    		if(firstC!=1){
    			fathers=uht.get(firstC-1);
    		}else{
    			fathers=new ArrayList<NodeDD>();
    		}
 
    		for(int i=0; i<fathers.size(); i++){
    			uht.removeFromTable(fathers.get(i));
    		}

    		//opp
    			//on doit creer une liste de depart car les noeuds sont suceptibles de change de place dans le parcours de la hashtable
    		ArrayList<Arc> arcsDepart=new ArrayList<Arc>();
    		for(int i=0; i<tableNode.size(); i++){
    			for(int j=0; j<tableNode.get(i).fathers.size(); j++){
    				arcsDepart.add(tableNode.get(i).fathers.get(j));
    			}
    		}
    		
    		for(int i=0; i<arcsDepart.size(); i++)
				valeurChemin(arcsDepart.get(i), varliste, poidliste, varlistind, softConstraint, defaultCost);		//on prend un arc au pif de tous les neuds de v1 de la contrainte

    		
    		//for(int i=0; i<tableNode.length; i++){
    		//	for(int j=0; j<tableNode[i].fathers.size(); j++){
    				//valeurChemin(tableNode[i].fathers.get(j), varliste, varlistind, softConstraint, defaultCost);		//on prend un arc au pif de tous les neuds de v1 de la contrainte
    		//	}
    		//}
    		
    		//on remet les peres
    		for(int i=0; i<fathers.size(); i++){
    			uht.ajoutNormaliseReduitPropage(fathers.get(i));
    		}
    		
    		//for(int i=0; i<fathers.size(); i++){
    		//	uht.ajoutNormaliseReduit(fathers.get(i));
    		//}
    		//if(fathers.size()>0)
    		//uht.normaliser(fathers.get(0).variable.pos);
    	}
    	
    	
    	//on retablis les noeuds finaux non parcourus
/*    	if(flagDefaultCost){
    		for(int i=0; i<liste.size(); i++){        		
    			if(liste.get(i).cpt!=1){
    				uht.ajoutNormaliseReduitPropage(liste.get(i));
    			}
    		}
    	}*/
    	
    	uht.supprNeudNegatifs();
    	uht.copieToNull();			//+ a remonter to null
    	uht.cptTo(0);
    }

//operateurs
    
    //operation addition, fction recursive
/*	public void add(NodeDD curr, NodeDD n, Arc a){
		if(curr.isLeaf()){							//cas feuille
			a.changerFils(n);
			a.addVal(curr.value);
			
			if(curr.fathers.size()==0){		//neud orphelin, a supprimer
				curr.cpt=-1;				
			}
		}else{
			if(curr.cpt!=0){			//arc non deja vu!
										//cas pas feuille
				if(curr.cpt==curr.fathers.size() || curr.fathers.size()==0){	//pas de souci (cas normal) || premier de liste		//a supprimer des que arc premier ajoute
					curr.cpt=0;
					for(int i=0; i<curr.kids.size(); i++)
						this.add(curr.kids.get(i).fils, n, curr.kids.get(i));		//on continue sur chaque fils
					
				}else{								//cas pas normal
					if(curr.copie==null){			//mais on y est pas encor passe
						NodeDD x=new NodeDD(curr, a, 0);		//copie conforme
						ut.add(x);
						curr.copie=x;								//on part pas sans laisser d'adresse
						
						a.changerFils(curr.copie);
						curr.cpt--;
						
						for(int i=0; i<x.kids.size(); i++)
							this.add(x.kids.get(i).fils, n, x.kids.get(i));		//on continue sur chaque fils de x
					}else{
						a.changerFils(curr.copie);
						curr.cpt--;
					}
					
				}
			}
		}
	}
    */
	
	//compte le nombre de passage dans chaques neud
	//resultat dans les cpt
    public double counting(){
    	double res=0;
    	if(first.actif && first.bottom==0)
    		first.fils.counting=1;
    	
    	for(int i=0; i<uht.get(0).size(); i++){
    		res+=counting(uht.get(0).get(i));
    	}
    	
    	uht.countingToMoinsUn();
    	return res;
    }
    
	public double counting(NodeDD n){		
		double res=0;
		if(n.counting!=-1){								//sinon on partirai plusieurs fois de chaque sommets
			return n.counting;
		}else{
			for(int i=0; i<n.fathers.size(); i++){
				if(n.fathers.get(i).bottom==0 && n.fathers.get(i).actif)
					res+=counting(n.fathers.get(i).pere);
			}
			n.counting=res;
			return res;
		}

		
	}
	/*
	//prend en compte la ponderation
	//cas de l'historique. (SLDD additif uniquement)
    public double countingpondere(){
    	double res=0;
    	if(first.actif && first.bottom==0)
    		first.fils.counting=1;
    	
    	for(int i=0; i<ut.get(0).size(); i++){
    		res+=countingpondere(ut.get(0, i));
    	}
    	
    	ut.countingToMoinsUn();
    	return res;
    }
    
	public double countingpondere(NodeDD n){				
		if(n.counting==-1){								//sinon on partirai plusieurs fois de chaque sommets
			n.counting=0;
			for(int i=0; i<n.fathers.size(); i++){
				if(n.fathers.get(i).bottom==0 && n.fathers.get(i).actif){
					countingpondere(n.fathers.get(i).pere);
					n.counting+=n.fathers.get(i).pere.counting;
					n.pondere+=n.fathers.get(i).pere.pondere + n.fathers.get(i).val*n.fathers.get(i).pere.counting;
				}
				
			}
		}
		return n.pondere;

		
	}
	*/
	
	//opt
	public void conditioner(int var, int val){
		uht.conditioner(var, val);
	}
	
	//opt
	public void conditioner(Var variable, int val){
		uht.conditioner(variable.pos, val);
	}
	
	public void conditionerTrue(int var, int val){
		ArrayList<NodeDD> savelist;//=new ArrayList<NodeDD>();
		savelist=uht.get(var);

		for(int i=0; i<savelist.size(); i++){
			uht.removeFromTable(savelist.get(i));
			savelist.get(i).conditionerTrue(val);
			uht.ajoutNormaliseReduitPropage(savelist.get(i));
		}
	}
	
	public void conditionerTrue(Var variable, int val){
		int var=variable.pos;
		ArrayList<NodeDD> savelist=new ArrayList<NodeDD>();
		for(int i=0; i<uht.size(var); i++){
			savelist=uht.get(var);
		}
		for(int i=0; i<savelist.size(); i++){
			uht.removeFromTable(savelist.get(i));
			savelist.get(i).conditionerTrue(val);
			uht.ajoutNormaliseReduitPropage(savelist.get(i));
		}
	}

	//opt
	//annnule le conditionnement de var
	public void deconditioner(int var){
		uht.deconditioner(var);
	}
	
	//opt
	//annnule le conditionnement de var
	public void deconditioner(Var variable){
		uht.deconditioner(variable.pos);
	}
	
	//opt
	public void deconditionerAll(){
		for(int j=1; j<=variables.size(); j++){
			uht.deconditioner(j);
		}
	}

	/*
	//ameliorable
	public double mostchoosen(int var){
		
		
		double max=-1;
		int indmax=-1;
		double val;
		for(int i=0; i<variables.get(var-1).domain; i++){
			this.deconditioner(var);
			this.conditioner(var, i);
			
			//val=this.countingpondere();
			val=this.countingpondere();
			if(val>max){
				max=val;
				indmax=i;
			}
			System.out.println("i:" + i + "  val:" + val);
		}
		deconditioner(var);
		
		
		return 0;
	}*/
	
	public void minMaxConsistance(){
		for(int i=0; i<variables.size(); i++)
			variables.get(i).consValTofalse();
		//uht.maxminNull();
		
		//bug premier dernier a resoudre
		
		
		//if(first.s.printstr().compareTo("Sp")==0){
				min=new Sp(); 
				max=new Sp(); 
		//}
		//if(first.s.printstr().compareTo("St")==0){
		//		min=new St(); 
		//		max=new St();
		//}
		//if(first.s.printstr().compareTo("Spt")==0){
		//		min=new Spt(); 
		//		max=new Spt();
		//}
		min.rendreInaccessible();
		max.rendreInaccessible();
		
//		long start= System.currentTimeMillis();
//		long end;
		
		uht.minMaxConsistance();
				
//		end=System.currentTimeMillis();
//		System.out.println("------> :  " + (end-start) + "ms");
		
		min=uht.get(0).get(0).min.copie();
		max=first.s.copie();
		max.operation(first.fils.max);
		if(min.printstr().compareTo("Spt")==0){
			min=first.s.copie();
			min.operation(first.fils.min);
//			System.out.println(((Spt)first.s).q +" "+((Spt)first.s).f);		
//			System.out.println(((Spt)first.fils.min).q +" "+((Spt)first.fils.min).f);		
//			System.out.println(((Spt)first.fils.max).q +" "+((Spt)first.fils.max).f);		
		}
		
		//System.out.println("min="+min.getvaldouble());		
		//System.out.println("max="+max.getvaldouble());

		/*for(int i=0; i<variables.size(); i++){
			System.out.print(variables.get(i).name+" ");
			for(int j=0; j<variables.get(i).domain; j++)
				System.out.print(variables.get(i).consVal[j]);
			System.out.println();
		}*/
		
		
	}
	
	public void minMaxConsistanceMaj(int var, boolean cd){
		//for(int i=0; i<variables.size(); i++)
			variables.get(var-1).consValTofalse();
		
		min.rendreInaccessible();
		max.rendreInaccessible();
		
		uht.minMaxConsistanceMaj(var, cd);
				
		//GIC();
		//for(int i=var; i<=variables.size(); i++)
		//	uht.GIC(i);
		
//		end=System.currentTimeMillis();
//		System.out.println("------> :  " + (end-start) + "ms");
		
		min=uht.get(0).get(0).min.copie();
		max=first.s.copie();
		max.operation(first.fils.max);
		if(min.printstr().compareTo("Spt")==0){
			min=first.s.copie();
			min.operation(first.fils.min);
//			System.out.println(((Spt)first.s).q +" "+((Spt)first.s).f);		
//			System.out.println(((Spt)first.fils.min).q +" "+((Spt)first.fils.min).f);		
//			System.out.println(((Spt)first.fils.max).q +" "+((Spt)first.fils.max).f);		
		}
		
	}
	
	public void minMaxConsistanceMajopt(int var, boolean cd){

		min.rendreInaccessible();
		max.rendreInaccessible();
		
		uht.minMaxConsistanceMajopt(var, cd);
				
//		end=System.currentTimeMillis();
//		System.out.println("------> :  " + (end-start) + "ms");
		min=uht.get(0).get(0).min.copie();
		max=first.s.copie();
		max.operation(first.fils.max);
		if(min.printstr().compareTo("Spt")==0){
			min=first.s.copie();
			min.operation(first.fils.min);
//			System.out.println(((Spt)first.s).q +" "+((Spt)first.s).f);		
//			System.out.println(((Spt)first.fils.min).q +" "+((Spt)first.fils.min).f);		
//			System.out.println(((Spt)first.fils.max).q +" "+((Spt)first.fils.max).f);		
		}
		//if(cd)
		//	GIC();
		for(int i=0; i<variables.size(); i++)
			variables.get(i).consValTofalse();
		uht.consGraceAMinMax();
		
	}
	
	public Map<String, String> minCostConfiguration(){
		Map<String, String> m=new HashMap<String, String>();
		int ind=-1;
		int pos=-1;
		NodeDD n;
		
		n=uht.get(0).get(0);
		
		while(n!=null){
			ind=n.posMin;
			pos=n.fathers.get(ind).pos;
			n=n.fathers.get(ind).pere;
			if(n!=null)
				m.put(n.variable.name, n.variable.valeurs.get(pos));
			//	System.out.print(n.variable.name +"->" +n.variable.valeurs.get(pos)+" ");
		}
		
		return m;
	}
	
	public Map<String, String> maxCostConfiguration(){
		Map<String, String> m=new HashMap<String, String>();
		int pos=-1;
		NodeDD n;
		
		n=first.fils;
		while(!n.isLeaf()){
			m.put(n.variable.name, n.variable.valeurs.get(pos));
			//System.out.print(n.variable.name+"->"+n.variable.valeurs.get(n.posMax)+" ");
			//ajouter entree n.variable.name, n.variable.valeurs.get(n.posMax)
			n=n.kids.get(n.posMax).fils;
		}	
		
		return m;
	}
	
	public Map<String, Integer> minCosts(int var){
		Map<String, Integer> m=new HashMap<String, Integer>();
		ArrayList<NodeDD> liste;
		uht.minMaxDomainVariable(var);
		liste=uht.get(var);
		int[] minDom=new int[this.variables.get(var-1).domain];
//		int[] maxDom=new int[this.variables.get(var-1).domain];
		for(int i=0; i<minDom.length; i++){
			minDom[i]=2147483647;
//			maxDom[i]=-1;
		}
		
		for(int i=0; i<liste.size(); i++){
			for(int j=0; j<liste.get(i).kids.size(); j++){
				if(liste.get(i).kids.get(j).fils!=null){
					if(liste.get(i).min.getvaldouble()!=-1 && liste.get(i).kids.get(j).fils.min.getvaldouble()!=-1){
						if(liste.get(i).min.getvaldouble()+liste.get(i).kids.get(j).s.getvaldouble()+liste.get(i).kids.get(j).fils.min.getvaldouble()<minDom[j])
							minDom[j]=(int) (liste.get(i).min.getvaldouble()+liste.get(i).kids.get(j).s.getvaldouble()+liste.get(i).kids.get(j).fils.min.getvaldouble());
//						if(liste.get(i).max.getvaldouble()+liste.get(i).kids.get(j).s.getvaldouble()+liste.get(i).kids.get(j).fils.max.getvaldouble()>maxDom[j])
//							maxDom[j]=(int) (liste.get(i).max.getvaldouble()+liste.get(i).kids.get(j).s.getvaldouble()+liste.get(i).kids.get(j).fils.max.getvaldouble());
					}
				}
			}
		}
			
		for(int i=0; i<minDom.length; i++){
			if(minDom[i]!=2147483647)
				m.put(variables.get(var-1).valeurs.get(i), minDom[i]);
			else
				m.put(variables.get(var-1).valeurs.get(i), -1);
		}
//		for(int i=0; i<minDom.length; i++){
//			System.out.print(maxDom[i]+" ");
//		}
		
		uht.minMaxConsistance();

		return m;
	} 
	
	public Map<String, Integer> maxCosts(int var){
		Map<String, Integer> m=new HashMap<String, Integer>();
		ArrayList<NodeDD> liste;
		uht.minMaxDomainVariable(var);
		liste=uht.get(var);
//		int[] minDom=new int[this.variables.get(var-1).domain];
		int[] maxDom=new int[this.variables.get(var-1).domain];
		for(int i=0; i<maxDom.length; i++){
//			minDom[i]=2147483647;
			maxDom[i]=-1;
		}
		
		for(int i=0; i<liste.size(); i++){
			for(int j=0; j<liste.get(i).kids.size(); j++){
				if(liste.get(i).kids.get(j).fils!=null){
					if(liste.get(i).max.getvaldouble()!=-1 && liste.get(i).kids.get(j).fils.max.getvaldouble()!=-1){
//						if(liste.get(i).min.getvaldouble()+liste.get(i).kids.get(j).s.getvaldouble()+liste.get(i).kids.get(j).fils.min.getvaldouble()<minDom[j])
//							minDom[j]=(int) (liste.get(i).min.getvaldouble()+liste.get(i).kids.get(j).s.getvaldouble()+liste.get(i).kids.get(j).fils.min.getvaldouble());
						if(liste.get(i).max.getvaldouble()+liste.get(i).kids.get(j).s.getvaldouble()+liste.get(i).kids.get(j).fils.max.getvaldouble()>maxDom[j])
							maxDom[j]=(int) (liste.get(i).max.getvaldouble()+liste.get(i).kids.get(j).s.getvaldouble()+liste.get(i).kids.get(j).fils.max.getvaldouble());
					}
				}
			}
		}
			
		for(int i=0; i<maxDom.length; i++){
			m.put(variables.get(var-1).valeurs.get(i), maxDom[i]);
		}
//		for(int i=0; i<minDom.length; i++){
//			System.out.print(maxDom[i]+" ");
//		}
		
		uht.minMaxConsistance();

		return m;
	} 
	
	public void GIC(){
		for(int i=0; i<variables.size(); i++)
			variables.get(i).consValTofalse();
		uht.GIC();
	}
	
	//pour un cd
	public void GICup(){
		for(int i=0; i<variables.size(); i++)
			if(variables.get(i).consistenceSize()>1){
				variables.get(i).consValTofalse();
				uht.GIC(i+1);
			}
	}
	
	//pour un dcd
	public void GICdown(){
		for(int i=0; i<variables.size(); i++)
			if(!variables.get(i).consistenceFull()){
				variables.get(i).consValTofalse();
				uht.GIC(i+1);
			}
	}
	
	//operation addition recursive
    public void add(VDD a, VDD b, ArrayList<NodeDD> listP, int etage){
    	ArrayList<NodeDD> listF=new ArrayList<NodeDD>();
    	NodeDD template;
    	
    	System.out.println(a.uht.size()+" "+a.uht.size(0)+" "+a.uht.size(1)+ " "+a.uht.size(2));
    	System.out.println(b.uht.size()+" "+b.uht.size(0)+" "+b.uht.size(1)+ " "+b.uht.size(2));

    	
    	etage++;
    	if(etage<=variables.size()){
    		template=a.uht.get(etage).get(0);
 
	    	
	    	System.out.println("listPsize:"+listP.size());
	    	//uht.removeFromTable(template);
	    	
	    	System.out.println(listP.get(0).variable.name+" "+listP.get(0).variable.domain);
	    	for(int i=0; i<listP.size(); i++){
	    		for(int j=0; j<listP.get(0).variable.domain; j++){
	    			System.out.println("boucle:"+j);
	    			NodeDD node1, node2;
	    			node1=listP.get(i).copie.get(0);
	    			node2=listP.get(i).copie.get(1);
	    			if(node1.kids.get(j).bottom==0 && node2.kids.get(j).bottom==0){			//sinon : bottom
	    				NodeDD nouveau = null;
	    				System.out.println(listF.size());
	    				for(int k=0; k<listF.size(); k++){
	    					if(listF.get(k).copie.get(0)==node1.kids.get(j).fils && listF.get(k).copie.get(1)==node2.kids.get(j).fils){
	    						nouveau=listF.get(k);
	    						break;
	    					}
	    				}
	    				if(nouveau==null){
	    					nouveau=new NodeDD(template, new Arc(listP.get(i), last, j, false, new Sp()));
	    					listP.get(i).kids.get(j).s.initOperation(node1.kids.get(j).s, node2.kids.get(j).s);
	    					listF.add(nouveau);
	    					nouveau.copie.add(node1.kids.get(j).fils);
	    					nouveau.copie.add(node2.kids.get(j).fils);
	    				}else{
	    					new Arc(listP.get(i), nouveau, j, new Sp());
	    					listP.get(i).kids.get(j).s.initOperation(node1.kids.get(j).s, node2.kids.get(j).s);
	    				}
	    			}else{
	    				//bottom
	    			}
	    			
	    		}
	    		uht.add(listP.get(i));
	    		System.out.println("size:"+listP.size()+" uht:"+uht.size()+" F:"+listF.size());
	    	}
	    	add(a, b, listF, etage);
    	
       	}
    	else{
	    	for(int i=0; i<listP.size(); i++){
	    		for(int j=0; j<listP.get(0).variable.domain; j++){ 
	    			new Arc(listP.get(i), last, j, false, new Sp());
					listP.get(i).kids.get(j).s.initOperation(listP.get(i).copie.get(0).kids.get(j).s, listP.get(i).copie.get(1).kids.get(j).s);

	    		}
	    		uht.add(listP.get(i));
	    	}
    	}
    	
 	}
    
    //operation addition init
    public void add(VDD a, VDD b){
    		
    	variables=a.variables;
    	
//        protected NodeDD first;							//the one first node (si plusieurs, creer plusieurs 
//        protected Arc first;
//        static NodeDDlast last;
    	first=new Arc(new NodeDD(variables.get(0)), true);
        last=new NodeDDlast ();
        uht.add(last);
        
    	flagPlus=a.flagPlus;
    	flagMult=a.flagMult;
    	
    	this.first.s.initOperation(a.first.s, b.first.s);
    	this.first.fils.copie.add(a.first.fils);
    	this.first.fils.copie.add(b.first.fils);				//pas besoin de suppr ce noeud pour tout ca
    	
    	ArrayList<NodeDD> listP=new ArrayList<NodeDD>();
    	System.out.println();
    	listP.add(first.fils);
    	
    	this.add(a, b, listP, 1);
    	
    	this.toDot("xplop", true);
    	
    	uht.copieToNull();
    	uht.normaliser();   	
 	}
    
	//fusion de deux VDD dont la premiere variable est concatennée
/*	public void fusion (VDD vdd2){
		for(int i=0; i<first.fils.variable.domain; i++){
			if(first.fils.kids.get(i).bottom>0)	{					//si il a été cuté
				if(vdd2.first.fils.kids.get(i).bottom==0){			//mais pas sur vdd2
					vdd2.first.fils.kids.get(i).changerPere(this.first.fils.kids.get(i));
				}
			}
		}
	}*/
	
	//test si notre ADD doit plutot etre transphorme en SLDD+ ou SLDD*
	//true -> SLDD+
	//false -> SLDD*
/*	public boolean testplus_testtime(){
		double moy=0;
		int size=ut.get(0).size();
		for(int i=0; i<size; i++){
			moy+=(ut.get(0).get(i).value/size);
		}
		if(moy>1)
			return true;
		else
			return false;
	}*/
	
//accesseurs
    
	public UniqueHashTable getUHT(){
		return uht;
	}

//afficheurs
	/*
    void plot(LddNode*, int);       // affichage de l'arbre depuis le neud (recursif)
    void plot();                    // affichage de l'arbre depuis la racine

    void plotVector();              // affichage du detail de l'ensemble des neuds

    void addToDot(string); // affichage en dot (passage par fichier)
    void slddToDot(string);
    */
    
/*    public String toString(){
    	ut.giveIndex();
    	
    	String s="";	
	 
	    	//nodes
    	for(int i=0; i<ut.nbVariables+1; i++)
	    	for(int j=0; j<ut.size(i); j++){
	    		//name label form
	    		s+=ut.get(i, j).toString();		//true non definitif (binary only)
	    	}
	    	
	    	return s;
    }*/
    
    public void toDot(String nameGraph, boolean afficheGraph){
    	
    	FileWriter fW;
//    	File f;
    	
    	String s;

		//fichier
		String name_file= "./" + nameGraph + ".dot";
		String name_pdf= "./" + nameGraph + ".pdf";
		try{
			fW = new FileWriter(name_file);
		
			//entete comenté
			if(flagPlus)
				if(flagMult)
					s="//AADD\n";
				else
					s="//SLDDp\n";
			else
				if(flagMult)
					s="//SLDDt\n";
				else
					s="//ADD\n";
			fW.write(s);
			
			for(int i=0; i<variables.size(); i++){
				s="// "+i+" "+variables.get(i).name;
				for(int j=0; j<variables.get(i).domain; j++)
					s+=" " + variables.get(i).valeurs.get(j);
				s+="\n";
				fW.write(s);
			}
				
			
	    	//entete
	    	s="digraph "+nameGraph+" {\n";
	    	fW.write(s);
	    	
	    	//first arc
	    	s=first.toDot();
    		fW.write(s);
	    	
	    	//nodes
    		ArrayList<NodeDD> l;
    		for(int i=0; i<uht.nbVariables+1; i++){
    			l=uht.get(i);
		    	for(int j=0; j<l.size(); j++){
		    		//name label form
		    		s=l.get(j).toDot();		//true non definitif (binary only)
		    		fW.write(s);
		    	}
	    	}
    	
    		
    		/*for(int i=0; i<uht.nbVariables+1; i++)
		    	for(int j=0; j<uht.size(i); j++){
		    		//name label form
		    		s=uht.get(i).get(j).toDot();		//true non definitif (binary only)
		    		fW.write(s);
		    	}
	    	*/
	    	s="}\n";
	    	fW.write(s);
	    	
	    	fW.close(); 
    	
		}catch(java.io.IOException exc){System.out.println("pb de fichier: " + exc);}
    
		if(afficheGraph){
			try {	//creation pdf
				Runtime.getRuntime().exec("/usr/bin/dot dot -Tpdf " + name_file + " -o " + name_pdf);
			} catch (java.io.IOException exc) {System.out.println("pb de creation pdf: " + exc); }
	
			try {	//ouverture pdf
				Runtime.getRuntime().exec("/usr/bin/evince evince " + name_pdf);
			} catch (java.io.IOException exc) {System.out.println("pb d'ouverture pdf: " + exc); }
		}
    }
    
    public void toXML(String nameGraph){
    	
    	FileWriter fW;
    	
    	String s;
    	
		String name_file= "./" + nameGraph + ".xml";

		//fichier
		try{
			fW = new FileWriter(name_file);
		
			//0 instance
			fW.write("<instance>\n");
			//1 presentation	/presentation
			s="\t<presentation format=\"XmlVdd\" type=\"slddplus\" name=\""+nameGraph+"\"/>\n";
			fW.write(s);
			//1 domains
			s="\t<domains nbDomains=\""+ this.variables.size() +"\">\n";
			fW.write(s);
			
			//2 domain
			for(int i=0; i<this.variables.size(); i++){
				s="\t\t<domain name=\"D"+ this.variables.get(i).name +"\" nbValues=\""+ this.variables.get(i).domain +"\">\n";
				fW.write(s);
				for(int j=0; j<this.variables.get(i).domain; j++){
					//3 val
					s="\t\t\t<val name=\""+ this.variables.get(i).valeurs.get(j) +"\"/>\n";
					fW.write(s);
				}
				fW.write("\t\t</domain>\n");
			}
			fW.write("\t</domains>\n");
			
			//1 variables
			s="\t<variables nbVariables=\""+ this.variables.size() +"\">\n";
			fW.write(s);
			for(int i=0; i<this.variables.size(); i++){
				//2 variable
				s="\t\t<variable name=\""+ this.variables.get(i).name +"\" domain=\"D"+ this.variables.get(i).name +"\"/>\n";
				fW.write(s);
			}
			fW.write("\t</variables>\n");
			
			
			//1 automate
			s="\t<automate nbNiv=\""+ this.variables.size() +"\" type=\"slddplus\" offset=\""+ first.s.toTxt() +"\" root=\"q"+first.fils.id+"\" sink=\"q"+last.id+"\" ordered=\"true\">\n";
			fW.write(s);
			
			for(int i=1; i<this.variables.size()+1; i++){
				//2 niveau
				s="\t\t<niveau variable=\""+ this.variables.get(i-1).name +"\" nbNoeuds=\""+uht.size(i)+"\" nbTransitions=\""+uht.sizeArcs(i)+"\">\n";
				fW.write(s);
				ArrayList<NodeDD> l=uht.get(i);
				for(int j=0; j<l.size(); j++){
					for(int k=0; k<l.get(j).kids.size(); k++){
						//3 trans
						if(l.get(j).kids.get(k).bottom==0){
							s="\t\t\t<trans inNode=\"q"+l.get(j).id+"\" value=\""+l.get(j).kids.get(k).pos+"\" outNode=\"q"+l.get(j).kids.get(k).fils.id+"\" phi=\""+l.get(j).kids.get(k).s.toTxt()+"\"/>\n";
							fW.write(s);
						}
					}
				}
				fW.write("\t\t</niveau>\n");
			}
			
			fW.write("\t</automate>\n");
			fW.write("</instance>\n");
			
		
	    	
	    	fW.close(); 
    	
		}catch(java.io.IOException exc){System.out.println("pb de fichier: " + exc);}
    
    }
    
    public VDD clone(){
    	NodeDD m,n;
    	Arc curr;
    	int index;
    	ArrayList<NodeDD> lp1, lf1, lp2, lf2;
    	lp1=new ArrayList<NodeDD>();
    	lf1=new ArrayList<NodeDD>();
    	lp2=new ArrayList<NodeDD>();
    	lf2=new ArrayList<NodeDD>();

    	n=new NodeDD(first.fils.variable, first.fils.id);
    	VDD newVDD=new VDD(new Arc(n, this.first.s.copie()), new UniqueHashTable(uht.nbVariables), this.variables);
    	curr=newVDD.first;
    	newVDD.uht.add(newVDD.last);
    	
    	lp1.add(first.fils);
    	lp2.add(n);
    	newVDD.first.changerFils(n);
    	
    	
    	for(int i=2; i<=variables.size(); i++){
    		lf1=uht.get(i);
    		for(int j=0; j<lf1.size(); j++)
    			lf2.add(new NodeDD(lf1.get(j).variable, lf1.get(j).id));
    		for(int j=0; j<lp1.size(); j++){
    			for(int k=0; k<lp1.get(j).kids.size(); k++){
    				if(lp1.get(j).kids.get(k).bottom!=0){
    					new Arc(lp2.get(j), null, k, true, lp1.get(j).kids.get(k).s.copie());
    				}else{
    					index=lf1.indexOf(lp1.get(j).kids.get(k).fils);
    					new Arc(lp2.get(j), lf2.get(index), k, false, lp1.get(j).kids.get(k).s.copie());
    				}
    			}
    			newVDD.uht.add(lp2.get(j));
    		}
    		
    		lp1.clear();
    		lp2.clear();
    		lp1=lf1;
    		lp2=lf2;
    		lf1=new ArrayList<NodeDD>();
    		lf2=new ArrayList<NodeDD>();
    		
    	}
    	
		
		for(int j=0; j<lp1.size(); j++){
			for(int k=0; k<lp1.get(j).kids.size(); k++){
				if(lp1.get(j).kids.get(k).bottom!=0){
					new Arc(lp2.get(j), null, k, true, lp1.get(j).kids.get(k).s.copie());
				}else{
					new Arc(lp2.get(j), newVDD.last, k, false, lp1.get(j).kids.get(k).s.copie());
				}
			}
			newVDD.uht.add(lp2.get(j));
		}
		
		return newVDD;
    }
    
    //renvoie la var correspondant a la string s
    public Var getVar(String s){
    	for(int i=0; i<variables.size(); i++){
    		if(variables.get(i).name.compareTo(s)==0){
    			return variables.get(i);
    		}
    	}
    	return null;
    }
    

    
    
    
}
