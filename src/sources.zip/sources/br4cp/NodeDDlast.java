package br4cp;

import java.util.ArrayList;


public class NodeDDlast extends NodeDD {
	
	public ArrayList<Double> add; 
	
	public NodeDDlast(){
		super(null);
		add=new ArrayList<Double>();
	}
	
	public NodeDDlast(int id){
		super(null, id);
		add=new ArrayList<Double>();
	}
	
	public boolean isLeaf(){
		return true;
	}	
}
